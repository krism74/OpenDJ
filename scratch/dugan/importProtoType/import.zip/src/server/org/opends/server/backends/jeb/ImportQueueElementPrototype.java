/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import com.sleepycat.je.DatabaseEntry;
import java.util.ArrayList;
import java.util.List;
import org.opends.server.types.Attribute;
import org.opends.server.types.Entry;

/**
 * A work item for the import protype that is passed on the work queue.
 */
public class ImportQueueElementPrototype {

  //Item is id2entry.
  private ID2Entry id2entry;

  //Item is index.
  private Index index;

  //Used by id2entry work item. Database key and database entry representations.
  private DatabaseEntry key;

  private Entry entry;

  //Used by index work items. Array list of ids.
  private ArrayList<EntryID> IDs;

  //Used by index work items. List off attributes.
  private List<Attribute> attrList;

  /**
   * Construct a work item using specified attribute list and array of IDs. Used
   * when index a general index.
   *
   * @param index The index to insert into.
   * @param attrList List of attributes to generate keys for.
   * @param IDs IDs to insert into DB.
   */
  private ImportQueueElementPrototype(Index index, List<Attribute> attrList,
                           ArrayList<EntryID> IDs ) {
   this.index=index;
   this.attrList=attrList;
   this.IDs=IDs;
  }

  /**
   * Construct work item using specified array of IDs. Used when index is
   * id2children/id2subtree.
   *
   * @param index The index to insert into.
   * @param IDs List of IDs to insert into DB.
   */
  private ImportQueueElementPrototype(Index index, ArrayList<EntryID> IDs) {
    this.index=index;
    this.IDs=IDs;
  }

  /**
   * Construct work item using specified database key and entry. Used when
   * work item is id2entry.
   *
   * @param id2entry ID2Entry DB.
   * @param key The database key to use.
   * @param entry The database entry to create.
   */
  private ImportQueueElementPrototype(ID2Entry id2entry, DatabaseEntry key,
                           Entry entry) {
    this.entry=entry;
    this.key = key;
    this.id2entry=id2entry;
  }

  /**
   * Create work item when index is a general index.
   * @param index The index to insert into.
   * @param attrList List of attributes to generate keys for.
   * @param IDs IDs to insert into DB.
   * @return ImportWorkItem representing a general index work item.
   */
  public static  ImportQueueElementPrototype
  decode(Index index, List<Attribute> attrList, ArrayList<EntryID> IDs) {
    return new ImportQueueElementPrototype(index, attrList, IDs);
  }

  /**
   * Create work item when ID2ENTRY is the work item.
   * @param id2Entry The ID2ENTRY database object.
   * @param key The database key to use.
   * @param entry The database entry to create.
   * @return ImportWorkItem representing a ID2ENTRY work item.
   */
  public static
  ImportQueueElementPrototype decode(ID2Entry id2Entry, DatabaseEntry key,
                               Entry entry) {
    return new ImportQueueElementPrototype(id2Entry, key, entry);
  }

  /**
   * Create a work item that uses a array list of IDs to get a key (ID2CHILDREN/
   * ID2SUBTREE).
   *
   * @param index  The index to insert into.
   * @param IDs IDs to insert into DB.
   * @return ImportWorkItem representing a index work item.
   */
  public static
  ImportQueueElementPrototype decode(Index index, ArrayList<EntryID> IDs)  {
    return new ImportQueueElementPrototype(index, IDs);
  }

  /**
   * Return the ID2NETRY object.
   *
   * @return The ID2ENTRY object.
   */
  public ID2Entry getID2Entry() {
    return id2entry;
  }

  /**
   * Return the index to insert into.
   *
   * @return The index to insert into.
   */
  public Index getIndex() {
    return index;
  }

  /**
   * Return the key to use in the insert in database format.
   *
   * @return The key.
   */
  public DatabaseEntry getIDKey() {
    return key;
  }

  /**
   * Return the entry to add in database format.
   *
   * @return The entry to add.
   */
  public Entry getEntry() {
    return entry;
  }

  /**
   * Return the entry ID (ID of index 0 of the ID list).
   *
   * @return The entry ID.
   */
  public EntryID getEntryID() {
    return IDs.get(0);
  }

  /**
   * Return the list of IDs.
   *
   * @return The ID list.
   */
  public ArrayList<EntryID> getIDs() {
    return IDs;
  }

  /**
   * Return the list of attributes.
   *
   * @return The attribute list.
   */
  public List<Attribute> getAttrList() {
    return attrList;
  }

  /**
   * VLV Index not supported in prototype.
   *
   * @return null.
   */
  public VLVIndex getVLVIndex() {
    return null;
  }
}
