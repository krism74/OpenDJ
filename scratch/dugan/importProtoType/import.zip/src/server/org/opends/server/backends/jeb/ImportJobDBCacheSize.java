/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */
package org.opends.server.backends.jeb;

import org.opends.server.types.*;
import org.opends.server.util.LDIFReader;
import org.opends.server.util.StaticUtils;
import org.opends.server.util.LDIFException;
import org.opends.server.util.RuntimeInformation;
import org.opends.server.config.ConfigException;
import static org.opends.server.loggers.ErrorLogger.logError;
import static org.opends.server.loggers.debug.DebugLogger.debugEnabled;
import static org.opends.server.loggers.debug.DebugLogger.getTracer;
import org.opends.server.loggers.debug.DebugTracer;
import org.opends.server.admin.std.server.LocalDBBackendCfg;
import org.opends.server.admin.std.server.LocalDBIndexCfg;
import org.opends.server.admin.std.meta.LocalDBIndexCfgDefn;
import org.opends.messages.Message;
import static org.opends.messages.JebMessages.*;

import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.atomic.AtomicLong;
import java.util.*;
import java.io.*;

import com.sleepycat.je.*;
import com.sleepycat.je.util.DbCacheSize;

public class ImportJobDBCacheSize implements ImportKeyCache,
        Thread.UncaughtExceptionHandler {

    private static final DebugTracer TRACER = getTracer();

  private CopyOnWriteArrayList<ImportThreadDbCacheSize> threads;

  private LDIFImportConfig ldifImportConfig;

  private LDIFReader reader;

  private int threadCount;

  private BlockingQueue<ImportWorkItemDbCacheProto> queue;

  private AtomicLong nextid = new AtomicLong(1);

  private LocalDBBackendCfg cfg;
  private DN lparentDN;
  private ArrayList<EntryID> lIDs;
  private HashMap<DN,EntryID> parentIDMap = new HashMap<DN,EntryID>();
  private HashMap<DN, EntryID> dn2idMap = new HashMap<DN, EntryID>();
  private HashMap<AttributeType, ImportIndexContainer> indexerMap =
                             new HashMap<AttributeType, ImportIndexContainer>();

  private HashMap<Indexer, HashMap<ByteArray, Longs>> dbCacheIndexerMap =
          new HashMap<Indexer, HashMap<ByteArray, Longs>>();
  private ConcurrentHashMap<ByteArray, ByteArray> keyMap =
          new ConcurrentHashMap<ByteArray, ByteArray>();
  private Set<DN> baseDNs;
  private Indexer id2CIndexer, id2SIndexer;
  private DataConfig dConfig;
  private int indexEntryLimit;
  private long keyBytes = 0, valBytes = 0;
  private int numDBEntries = 0;
  private int ldifReadSize=0, recordTotal=0;
  private int entriesRead = 0;
  private Object jobSynchronizer = new Object();
  private int indexSubStr;
  private long keyHit = 0;
  int ratio = 0;

  public ImportJobDBCacheSize(LDIFImportConfig ldifImportConfig,
                              LocalDBBackendCfg cfg, int ldifReadSize,
                              int recordTotal) {
    this.ldifImportConfig = ldifImportConfig;
    this.threads = new CopyOnWriteArrayList<ImportThreadDbCacheSize>();
    this.queue =  new LinkedBlockingQueue<ImportWorkItemDbCacheProto> (100);
    this.cfg = cfg;
    this.threadCount = cfg.getImportThreadCount();
    this.baseDNs = cfg.getBaseDN();
    JECompressedSchema cSchema = new JECompressedSchema();
    this.dConfig = new DataConfig(cfg.isEntriesCompressed(),
                         cfg.isCompactEncoding(), cSchema);
    indexEntryLimit = cfg.getIndexEntryLimit();
    this.ldifReadSize = ldifReadSize;
    this.recordTotal = recordTotal;
  }

  public LDIFImportResult importLDIF()
          throws DatabaseException, IOException, JebException,
          DirectoryException,
          ConfigException {

    ldifImportConfig.setInvokeImportPlugins(true);
    reader = new LDIFReader(ldifImportConfig);

    long startTime;
    RuntimeInformation.logInfo();

    try
    {
      startTime = System.currentTimeMillis();
      //Figure out the import buffer sizes to give to each thread.
      long importSize=getImportBufferSize();
      id2CIndexer = new ID2CIndexer();
      id2SIndexer = new ID2SIndexer();
      loadIndexerMap();
      startWorkerThreads(importSize);
      try {
           processLDIF();
      }
      finally
      {
        stopWorkerThreads();
        collectIndexSizes();
      }
    }
    finally
    {
      reader.close();
    }
    System.out.println("Final keyBytes: " + keyBytes + " valBytes: " +
            valBytes +
            " numDBEntries: " + numDBEntries + " ratio: " +
            numDBEntries/entriesRead);
    System.out.println("Final key map" + " hits: " +
                       keyHit + " total: " + keyMap.size());
    long finishTime = System.currentTimeMillis();
    long importTime = (finishTime - startTime);

    if((ldifReadSize != 0 && entriesRead >= ldifReadSize)) {
      ratio = numDBEntries/entriesRead;
      System.out.println("LDIF subset desired using estimates: " + ratio + " " +
              ratio * recordTotal);
    }
    keyMap.clear();
    calcDBCacheSizes();
    return new LDIFImportResult(reader.getEntriesRead(),
            reader.getEntriesRejected(),
            reader.getEntriesIgnored());
  }


  private void calcDBCacheSizes() {
    int records = numDBEntries;
    long keySize =  keyBytes/numDBEntries;
    long dataSize = valBytes/numDBEntries;
    if(recordTotal != 0) {
      records = ratio * recordTotal;
    }
    StringBuilder cmd = new StringBuilder("java ");
    Runtime rt = Runtime.getRuntime();
    cmd.append("-cp " + System.getProperty("java.class.path") +
            " com.sleepycat.je.util.DbCacheSize" + " -key " + keySize +
            " -data " + dataSize + " -records " + records);
    try {
      Process proc = rt.exec(cmd.toString());
      InputStream inputstream =
              proc.getInputStream();
      InputStreamReader inputstreamreader =
              new InputStreamReader(inputstream);
      BufferedReader bufferedreader =
              new BufferedReader(inputstreamreader);
      String line;
      while ((line = bufferedreader.readLine())
              != null) {
        System.out.println(line);
      }
      try {
        if (proc.waitFor() != 0) {
          System.err.println("exit value = " +
                  proc.exitValue());
        }
      }
      catch (InterruptedException e) {
        System.err.println(e);
      }
    } catch (IOException ioe)
    {
      ioe.printStackTrace();
    }
  }


  private long getImportBufferSize() throws DatabaseException {
    Runtime runtime = Runtime.getRuntime();
    long freeMemory = runtime.freeMemory();
    long maxMemory = runtime.maxMemory();
    long totMemory = runtime.totalMemory();
    long totFreeMemory = (freeMemory + (maxMemory - totMemory));
    long slop = (totFreeMemory * 20) / 100;
    long retSize = totFreeMemory - (slop );
    retSize=retSize/threadCount;

    return retSize;
  }


  private void startWorkerThreads(long budgetLimit)
          throws DatabaseException {
    for (int i = 0; i < threadCount; i++)
    {
      ImportThreadDbCacheSize t =
              new ImportThreadDbCacheSize(queue, budgetLimit, i, this);
      t.setUncaughtExceptionHandler(this);
      threads.add(t);
      t.start();
    }
  }

  public void uncaughtException(Thread t, Throwable e) {
    threads.remove(t);
    Message msg = ERR_JEB_IMPORT_THREAD_EXCEPTION.get(
            t.getName(), StaticUtils.stackTraceToSingleLineString(e.getCause()));
    logError(msg);
  }

  private void stopWorkerThreads() throws DatabaseException {
    if(threads.size() > 0) {
      // Wait for the queues to be drained.
      while (queue.size() > 0) {
        try {
          Thread.sleep(100);
        } catch (Exception e) {
          // No action needed.
        }
      }
    }

    // Order the threads to stop.
    for (ImportThreadDbCacheSize t : threads) {
      t.stopProcessing();
    }

    // Wait for each thread to stop.
    for (ImportThreadDbCacheSize t : threads) {
      try {
        t.join();
      } catch (InterruptedException ie) {
        // No action needed?
      }
    }

    for(ImportThreadDbCacheSize t : threads) {
      numDBEntries += t.getNumDBEntries();
      keyBytes += t.getKeyBytes();
      valBytes += t.getValBytes();
    }
 //   System.out.println("Avg key: " + avgKey + " Avg val: " + valSize);
  }

  private void processLDIF()
          throws JebException, DatabaseException, IOException {
    Message message = INFO_JEB_IMPORT_LDIF_START.get();
    logError(message);

    do {
      if (ldifImportConfig.isCancelled()) {
        break;
      }

      if(threads.size() <= 0) {
        message = ERR_JEB_IMPORT_NO_WORKER_THREADS.get();
        throw new JebException(message);
      }
      try
      {
        // Read the next entry.
        Entry entry = reader.readEntry();
        entriesRead++;
        if(entriesRead % 5000 == 0) {
          System.out.println("Processed Entries: " + entriesRead);
          System.out.println("Key map" + " hits: " +
                              keyHit + " total: " + keyMap.size());
        }
        // Check for end of file.
        if (entry == null) {
          message = INFO_JEB_IMPORT_LDIF_END.get();
          logError(message);

          break;
        }
        if((ldifReadSize != 0 && entriesRead >= ldifReadSize)) {

          break;
        }
        processEntry (entry);

      }
      catch (LDIFException e)
      {
        if (debugEnabled()) {
          TRACER.debugCaught(DebugLogLevel.ERROR, e);
        }
      } catch (DirectoryException ex)  {
        if (debugEnabled()) {
          TRACER.debugCaught(DebugLogLevel.ERROR, ex);
        }
      }
    } while (true);
  }

  public EntryID getNextEntryID() {
    return new EntryID(nextid.getAndIncrement());
  }

  public void processEntry(Entry entry) throws DirectoryException {
    DN entryDN = entry.getDN();
    EntryID entryID = getNextEntryID();
    EntryID parentID = null;
    DN parentDN = getParentWithinBase(entryDN);
    if (parentDN != null) {
      parentID  = getParentID(parentDN, entryID);
      if (parentID == null) {
        System.out.println("no mama");
        return;
      }
    }
    dn2idMap.put(entryDN, entryID);
    keyBytes += StaticUtils.getBytes(entryDN.toNormalizedString()).length;
    numDBEntries++;
    valBytes += entryID.getDatabaseEntry().getData().length;
    ArrayList<EntryID> IDs;
    if (parentDN != null && getParentDN() != null &&
            parentDN.equals(getParentDN())) {
      IDs = new ArrayList<EntryID>(getIDs());
      IDs.set(0, entryID);
      dn2idMap.remove(entryDN);
    } else {
      IDs = new ArrayList<EntryID>(entryDN.getNumComponents());
      IDs.add(entryID);
      if (parentID != null) {
        IDs.add(parentID);
        for (DN dn = getParentWithinBase(parentDN);
             dn != null;
             dn = getParentWithinBase(dn)) {
          EntryID nodeID = parentIDMap.get(dn);
          IDs.add(nodeID);
        }
      }
    }
    setParentDN(parentDN);
    setIDs(IDs);
    addID2EntryQueue(entryID, entry);
    addID2SubtreeChildrenQueue(IDs);
    addIndexesQueue(IDs, entry);
  }

  private EntryID getParentID(DN parentDN, EntryID id) {
   EntryID parentID = parentIDMap.get(parentDN);
   if (parentID != null) {
     return parentID;
   }
   parentID = dn2idMap.get(parentDN);
   if (parentID != null) {
      parentIDMap.put(parentDN, parentID);
      dn2idMap.remove(parentDN);
   }
   return parentID;
 }

  public DN getParentDN() {
    return lparentDN;
  }

  /**
   * Set the parent DN of the previous imported entry.
   * @param parentDN The parent DN of the previous imported entry.
   */
  public void setParentDN(DN parentDN) {
    this.lparentDN = parentDN;
  }

  /**
   * Get the superior IDs of the previous imported entry.
   * @return The superior IDs of the previous imported entry.
   */
  public ArrayList<EntryID> getIDs() {
    return lIDs;
  }

  /**
   * Set the superior IDs of the previous imported entry.
   * @param IDs The superior IDs of the previous imported entry.
   */
  public void setIDs(ArrayList<EntryID> IDs) {
    this.lIDs = IDs;
  }


  public DN getParentWithinBase(DN dn) {
    for(DN baseDN : baseDNs) {
      if(dn.equals(baseDN)) {
        return null;
      }
    }
    return dn.getParent();
  }

  private void loadIndexerMap() throws ConfigException {
    ImportIndexContainer c;
    for (String idx : cfg.listLocalDBIndexes()) {
      try {
        LocalDBIndexCfg indexConfig = cfg.getLocalDBIndex(idx);
        AttributeType attrType = indexConfig.getAttribute();
        c = new ImportIndexContainer();
        indexerMap.put(attrType, c);
        if (indexConfig.getIndexType().contains(
                LocalDBIndexCfgDefn.IndexType.EQUALITY)) {
          Indexer equalityIndexer = new EqualityIndexer(attrType);
          c.setEqIndexer(equalityIndexer);
          HashMap<ByteArray, Longs> keyHashMap  =
                  new HashMap<ByteArray, Longs>();
          dbCacheIndexerMap.put(equalityIndexer, keyHashMap);
        }
        if (indexConfig.getIndexType().contains(
                LocalDBIndexCfgDefn.IndexType.PRESENCE)) {
          Indexer presenceIndexer = new PresenceIndexer(attrType);
          c.setPresIndexer(presenceIndexer);
          HashMap<ByteArray, Longs> keyHashMap  =
                  new HashMap<ByteArray, Longs>();
          dbCacheIndexerMap.put(presenceIndexer, keyHashMap);
        }

        if (indexConfig.getIndexType().contains(
                LocalDBIndexCfgDefn.IndexType.SUBSTRING)) {
          if (attrType.getSubstringMatchingRule() == null)
          {
            Message message = ERR_CONFIG_INDEX_TYPE_NEEDS_MATCHING_RULE.get(
                    String.valueOf(attrType), "substring");
            throw new ConfigException(message);
          }
          indexSubStr = indexConfig.getSubstringLength();
          Indexer substringIndexer = new SubstringIndexer(attrType,
                  indexConfig.getSubstringLength());
          c.setSubStrIndexer(substringIndexer);
          HashMap<ByteArray, Longs> keyHashMap  =
                  new HashMap<ByteArray, Longs>();
          dbCacheIndexerMap.put(substringIndexer, keyHashMap);
        }
        if (indexConfig.getIndexType().contains(
                LocalDBIndexCfgDefn.IndexType.ORDERING)) {
          if (attrType.getOrderingMatchingRule() == null)
          {
            Message message = ERR_CONFIG_INDEX_TYPE_NEEDS_MATCHING_RULE.get(
                    String.valueOf(attrType), "ordering");
            throw new ConfigException(message);
          }

          Indexer orderingIndexer = new OrderingIndexer(attrType);
          c.setOrderIndexer(orderingIndexer);
          HashMap<ByteArray, Longs> keyHashMap  =
                  new HashMap<ByteArray, Longs>();
          dbCacheIndexerMap.put(orderingIndexer, keyHashMap);
        }
        if (indexConfig.getIndexType().contains(
                LocalDBIndexCfgDefn.IndexType.APPROXIMATE)) {
          if (attrType.getApproximateMatchingRule() == null)
          {
            Message message = ERR_CONFIG_INDEX_TYPE_NEEDS_MATCHING_RULE.get(
                    String.valueOf(attrType), "approximate");
            throw new ConfigException(message);
          }
          Indexer approximateIndexer = new ApproximateIndexer(attrType);
          c.setApproxIndexer(approximateIndexer);
          HashMap<ByteArray, Longs> keyHashMap  =
                  new HashMap<ByteArray, Longs>();
          dbCacheIndexerMap.put(approximateIndexer, keyHashMap);
        }
      } catch (Exception ex) {
        System.out.println("handler error");
      }
    }
    HashMap<ByteArray, Longs> keyHashMap  = new HashMap<ByteArray, Longs>();
    dbCacheIndexerMap.put(id2CIndexer, keyHashMap);
    keyHashMap  = new HashMap<ByteArray, Longs>();
    dbCacheIndexerMap.put(id2SIndexer, keyHashMap);
  }

  private boolean
  addQueue(ImportWorkItemDbCacheProto item) {
    try {
      while(!queue.offer(item, 1000, TimeUnit.MILLISECONDS)) {
        if(threads.size() <= 0) {
          // All worker threads died. We must stop now.
          return false;
        }
      }
    } catch (InterruptedException e) {
      if (debugEnabled()) {
        TRACER.debugCaught(DebugLogLevel.ERROR, e);
      }
    }
    return true;
  }

  private boolean addIndexesQueue(ArrayList<EntryID> IDs, Entry entry) {
    ImportIndexContainer c;
    Indexer indexer;
    for(Map.Entry<AttributeType, ImportIndexContainer> hashEntry :
            indexerMap.entrySet()) {
      AttributeType attrType = hashEntry.getKey();
      List<Attribute> aList=entry.getAttribute(attrType);
      if(entry.hasUserAttribute(attrType) ||
              entry.hasOperationalAttribute(attrType) ||
              attrType.isObjectClassType()) {
        c = hashEntry.getValue();
        if(c.getSubStrIndexer() != null) {
          indexer = c.getSubStrIndexer();
          ImportWorkItemDbCacheProto item =
                  ImportWorkItemDbCacheProto.decode(indexer, aList, IDs,
                          indexEntryLimit, this);
          if(!addQueue(item)) {
            return false;
          }
        }
        if(c.getEqIndexer() != null) {
          indexer = c.getEqIndexer();
          ImportWorkItemDbCacheProto item =
                  ImportWorkItemDbCacheProto.decode(indexer, aList, IDs,
                          indexEntryLimit,this);
          if(!addQueue(item)) {
            return false;
          }
        }
        if(c.getOrderIndexer() != null) {
          indexer = c.getOrderIndexer();
          ImportWorkItemDbCacheProto item =
                  ImportWorkItemDbCacheProto.decode(indexer, aList, IDs,
                          indexEntryLimit,this);
          if(!addQueue(item)) {
            return false;
          }
        }
        if(c.getPresIndexer() != null) {
          indexer = c.getPresIndexer();
          ImportWorkItemDbCacheProto item =
                  ImportWorkItemDbCacheProto.decode(indexer, aList, IDs,
                          indexEntryLimit, this);
          if(!addQueue(item)) {
            return false;
          }
        }
        if(c.getApproxIndexer() != null) {
          indexer = c.getApproxIndexer();
          ImportWorkItemDbCacheProto item =
                  ImportWorkItemDbCacheProto.decode(indexer, aList, IDs,
                          indexEntryLimit, this);
          if(!addQueue(item)) {
            return false;
          }
        }
      }
    }
    return true;
  }

  private boolean
  addID2SubtreeChildrenQueue(ArrayList<EntryID> IDs ) {


    ImportWorkItemDbCacheProto childItem =
            ImportWorkItemDbCacheProto.decode(id2CIndexer, IDs,
                                              indexEntryLimit, this);
    if(!addQueue(childItem)) {
      return false;
    }
    ImportWorkItemDbCacheProto subtreeItem =
            ImportWorkItemDbCacheProto.decode(id2SIndexer, IDs,
                                              indexEntryLimit, this);
    if(!addQueue(subtreeItem)) {
      return false;
    }
    return true;
  }

  private boolean
  addID2EntryQueue(EntryID entryID, Entry e)
          throws DirectoryException {
    ImportWorkItemDbCacheProto workItem =
            ImportWorkItemDbCacheProto.decode(entryID.getDatabaseEntry(),
                                              entryData(e), this);
    return addQueue(workItem);
  }

  public DatabaseEntry
  entryData(Entry entry)
          throws DirectoryException
  {
    byte[] entryBytes;
    entryBytes = JebFormat.entryToDatabase(entry, dConfig);
    return new DatabaseEntry(entryBytes);
  }

 public long doIds(Indexer indexer, ByteArray key, Longs bufLongs) {
   boolean maintainCount = false;
   Indexer hashIndexer = indexer;
   if((indexer == id2CIndexer) || (indexer == id2SIndexer)) {
     maintainCount = true;
   }
   HashMap<ByteArray, Longs> keyHashMap = dbCacheIndexerMap.get(hashIndexer);
   synchronized (jobSynchronizer) {
     if(keyHashMap == null) {
       return 0;
     }
       if(keyHashMap.containsKey(key)) {
         Longs hashLong = keyHashMap.get(key);
          if(maintainCount) {
            hashLong.mergeLongsCount(bufLongs, indexEntryLimit);
          } else {
            hashLong.mergeLongs(bufLongs, indexEntryLimit);
          }
       } else {
         keyHashMap.put(key, bufLongs);
       }
    }
   return 0;
 }

  private void collectIndexSizes() {
    for(Map.Entry<Indexer, HashMap<ByteArray, Longs>> mapEntry :
            dbCacheIndexerMap.entrySet()) {
      Indexer indexer = mapEntry.getKey();
      HashMap<ByteArray, Longs> keyHashMap = mapEntry.getValue();
      for(ByteArray key : keyHashMap.keySet()) {
        Longs bufLongs=keyHashMap.get(key);
        numDBEntries ++;
        keyBytes += key.array().length;
        if(bufLongs.isDefined()) {
          valBytes += (bufLongs.getCountOnly() * 8);
        } else {
          valBytes += 8;
        }
      }
      keyHashMap.clear();
    }
  }

  public int getIndexSubStr() {
    return indexSubStr;
  }

  public ByteArray checkKeyMap(ByteArray byteArray,
                               ImportMemoryBudgetProto memBudget) {
    ByteArray ret;
    if(!keyMap.containsKey(byteArray)) {
      int len = byteArray.array().length;
      byte[] bytes = new byte[len];
      System.arraycopy(byteArray.array(), 0, bytes, 0, len);
      ByteArray newBa = new ByteArray();
      newBa.setArray(bytes);
      ret = newBa;
      keyMap.put(newBa, newBa);
      if(memBudget != null) {
        memBudget.addMemoryUsageHashMapEntry();
      }
    } else {
      keyHit++;
      ret = keyMap.get(byteArray);
     // System.out.println(keyEff + " " + keyMap.size());
    }
    return ret;
  }

}
