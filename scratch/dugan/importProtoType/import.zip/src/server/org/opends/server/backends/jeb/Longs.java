/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2006-2007 Sun Microsystems, Inc.
 */
package org.opends.server.backends.jeb;

import java.io.DataInputStream;
import java.io.IOException;


/**
 * This class represents a sorted set of longs.  Internally it uses an array
 * that can grow when necessary. A goal of this class is to avoid memory
 * allocations where possible.  Added support for undefines for the import
 * prototype.
 */
public class Longs
{
  /**
   * The internal array where elements are stored.
   */
  private long[] array = null;

  /**
   * The number of valid elements in the array.
   */
  private int count = 0;

  //Size of the undefines.
  private long undefinedSize = 0;

  //Boolean to keep track if the instance is defined or not.
  boolean isDefined=true;

  //Add some padding to the array to it won't be resized when a long is added.
  private static final int padding = 15;

  /**
   * Construct a new empty set.
   */
  public Longs() {
  }

  /**
   * Returns the undefined size.
   * @return The undefined size.
   */
  public long getUndefinedSize() {
    return undefinedSize;
  }

  /**
   * Add specified entry ID to longs array, checking if the array has gone
   * over the specified limt. If the instance is defined and goes over the
   * limit then the instance is made undefined. This method is for the case
   * where the undefined size is kept.
   *
   * @param entryID The entry ID to add.
   * @param limit The entry ID limit.
   * @return The adjusted size of the array. May be negative if instance
   * went from defined to undefined, 0 if no resize occured or a positive
   * number if a array resize was needed.
   */
  public int addEntryIDCount(EntryID entryID, int limit) {
    int adjustedLen=0;
    if(!isDefined) {
      undefinedSize++;
    } else if((count + 1) >= limit) {
      isDefined = false;
      undefinedSize = count + 1;
      adjustedLen = 0 - array.length;
      count = 0;
      array = null;
    } else {
      int oldLen=array.length;
      add(entryID.longValue());
      adjustedLen=array.length - oldLen;
    }
    return adjustedLen;
  }

   /**
   * Add specified entry ID to longs array, checking if the array has gone
   * over the specified limt. If the instance is defined and goes over the
   * limit then the instance is made undefined. This method is for the case
   * where the undefined size not kept.
   *
   * @param entryID The entry ID to add.
   * @param limit The entry ID limit.
   * @return The adjusted size of the array. May be negative if instance
   * went from defined to undefined, 0 if no resize occured or a positive
   * number if a array resize was needed.
   */

  public int addEntryID(EntryID entryID, int limit) {
    int adjustedLen=0;
    if(!isDefined) {
       return 0;
    }
    if(isDefined && ((count + 1) > limit)) {
      isDefined = false;
      undefinedSize = Long.MAX_VALUE;
      adjustedLen = 0 - array.length;
      array = null;
      count = 0;
    } else {
       int oldLen = array.length;
       add(entryID.longValue());
       adjustedLen = array.length - oldLen;
    }
    return adjustedLen;
  }

  /**
   * Returns a byte array that can be used to add to the DB.
   *
   * @return A byte array that can be added to the DB.
   */
  public byte[] toDatabase() {
   if(isDefined) {
      return encode(null);
    } else {
      return JebFormat.entryIDUndefinedSizeToDatabase(undefinedSize);
    }
  }

  /**
   * Merge specified byte array from the DB with specified Longs from a
   * buffer, checking if it went over the entry limit. Keep a count if it does.
   *
   * @param DBbytes The DB byte array.
   * @param bufLongs The buffer Longs.
   * @param limit The entry limit.
   * @return <CODE>True</CODE> if adding the bufLongs caused the instance to
   *               be undefined.
   */
  public boolean
  mergeBytesCount(byte[] DBbytes, Longs bufLongs, int limit) {
    boolean incrLimitCount=false;
    boolean dbUndefined = ((DBbytes[0] & 0x80) == 0x80);

    if(dbUndefined && (!bufLongs.isDefined()))  {
       undefinedSize = JebFormat.entryIDUndefinedSizeFromDatabase(DBbytes) +
                      bufLongs.getUndefinedSize();
       isDefined=false;
    } else if(dbUndefined && (bufLongs.isDefined()))  {
       undefinedSize = JebFormat.entryIDUndefinedSizeFromDatabase(DBbytes) +
                      bufLongs.size();
       bufLongs.setUndefined();
       isDefined=false;
    } else if(!bufLongs.isDefined()) {
       int dbSize = JebFormat.entryIDListFromDatabase(DBbytes).length;
       undefinedSize= dbSize + bufLongs.getUndefinedSize();
       isDefined=false;
       incrLimitCount = true;
    } else {
      array = JebFormat.entryIDListFromDatabase(DBbytes);
      if(array.length + bufLongs.size() > limit) {
          undefinedSize = array.length + bufLongs.size();
          bufLongs.setUndefined();
          isDefined=false;
          incrLimitCount=true;
      } else {
        count = array.length;
        addAll(bufLongs);
      }
    }
    return incrLimitCount;
  }

  /**
   * Merge byte array and Longs from a bufer.
   *
   * @param DBbytes  The byte array.
   * @param bufLongs The Longs from the buffer.
   */
  private void merge(byte[] DBbytes, Longs bufLongs) {
    array = JebFormat.entryIDListFromDatabase(DBbytes);
    count = array.length;
    addAll(bufLongs);
  }


  /**
   * Merge specified byte array from the DB with specified Longs from a
   * buffer, checking if it went over the entry limit. Don't keep a count.
   *
   * @param DBbytes The DB byte array.
   * @param bufLongs The buffer Longs.
   * @param limit The entry limit.
   * @return <CODE>True</CODE> if adding the bufLongs caused the instance to
   *               be undefined.
   */
  public boolean mergeBytes(byte[] DBbytes, Longs bufLongs, int limit) {
    boolean incrLimitCount=false;
    boolean dbUndefined = ((DBbytes[0] & 0x80) == 0x80);

    if(dbUndefined) {
      undefinedSize = Long.MAX_VALUE;
      isDefined=false;
    } else if(!bufLongs.isDefined()) {
      undefinedSize = Long.MAX_VALUE;
      isDefined=false;
      incrLimitCount=true;
    } else {
      array = JebFormat.entryIDListFromDatabase(DBbytes);
      if(array.length + bufLongs.size() > limit) {
          undefinedSize = Long.MAX_VALUE;
          bufLongs.setUndefined();
          isDefined=false;
          incrLimitCount=true;
      } else {
        count = array.length;
        addAll(bufLongs);
      }
    }
    return incrLimitCount;
  }

  /**
   * Create a Longs instance from an entry ID. Makes the array a little larger
   * so appends will be faster.
   *
   * @param id  The entry ID.
   */
  public Longs (EntryID id) {
    this.array = new long[15];
    this.array[0] = id.longValue();
    count=1;
  }

  /**
   * Sets the undefined size to the specified size.
   *
   * @param undefinedSize The new undefined size.
   */
  public void setUndefinedSize(long undefinedSize) {
     this.undefinedSize=undefinedSize;
  }

  /**
   * Add specified size to the undefined size.
   *
   * @param size The size to add.
   */
  public void addUndefinedSize(long size) {
    this.undefinedSize += size;
  }

  /**
   * Mark an instance as undefined with no count being kept.
   */
  public void setUndefined() {
    isDefined=false;
    if(array != null) {
      array=null;
    }
  }

  /**
   * Return if this instance is defined.
   * @return <CODE>True</CODE> if the instance is defined.
   */
  public boolean isDefined() {
    return isDefined;
  }

  /**
   * Decodes a set from a byte array.
   * @param bytes The encoded value.
   */
  void decode(byte[] bytes)
  {
    if (bytes == null)
    {
      count = 0;
      return;
    }

    int count = bytes.length / 8;
    resize(count);

    for (int pos = 0, i = 0; i < count; i++)
    {
      long v = 0;
      v |= (bytes[pos++] & 0xFFL) << 56;
      v |= (bytes[pos++] & 0xFFL) << 48;
      v |= (bytes[pos++] & 0xFFL) << 40;
      v |= (bytes[pos++] & 0xFFL) << 32;
      v |= (bytes[pos++] & 0xFFL) << 24;
      v |= (bytes[pos++] & 0xFFL) << 16;
      v |= (bytes[pos++] & 0xFFL) << 8;
      v |= (bytes[pos++] & 0xFFL);
      array[i] = v;
    }
    this.count = count;
  }



  /**
   * Get the number of bytes needed to encode this value into a byte array.
   * @return The number of bytes needed to encode this value into a byte array.
   */
  public int encodedSize()
  {
    return count*8;
  }



  /**
   * Encode this value into a byte array.
   * @param bytes The array into which the value will be encoded.  If the
   * provided array is null, or is not big enough, a new array will be
   * allocated.
   * @return The encoded array. If the provided array was bigger than needed
   * to encode the value then the provided array is returned and the number
   * of bytes of useful data is given by the encodedSize method.
   */
  byte[] encode(byte[] bytes)
  {
    int encodedSize = encodedSize();
    if (bytes == null || bytes.length < encodedSize)
    {
      bytes = new byte[encodedSize];
    }

    for (int pos = 0, i = 0; i < count; i++)
    {
      long v = array[i];
      bytes[pos++] = (byte) ((v >>> 56) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 48) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 40) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 32) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 24) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 16) & 0xFF);
      bytes[pos++] = (byte) ((v >>> 8) & 0xFF);
      bytes[pos++] = (byte) (v & 0xFF);
    }

    return bytes;
  }



  /**
   * This is very much like Arrays.binarySearch except that it searches only
   * an initial portion of the provided array.
   * @param a The array to be searched.
   * @param count The number of initial elements in the array to be searched.
   * @param key The element to search for.
   * @return See Arrays.binarySearch.
   */
  private static int binarySearch(long[] a, int count, long key)
  {
    int low = 0;
    int high = count-1;

    while (low <= high)
    {
      int mid = (low + high) >> 1;
      long midVal = a[mid];

      if (midVal < key)
        low = mid + 1;
      else if (midVal > key)
        high = mid - 1;
      else
        return mid; // key found
    }
    return -(low + 1);  // key not found.
  }



  /**
   * Add a new value to the set.
   * @param v The value to be added.
   * @return true if the value was added, false if it was already present
   * in the set.
   */

  public boolean add(long v)
  {
    resize(count+1);

    if (count == 0 || v > array[count-1])
    {
      array[count++] = v;
      return true;
    }

    int pos = binarySearch(array, count, v);
    if (pos >=0)
    {
      return false;
    }

    // For a negative return value r, the index -(r+1) gives the array
    // index at which the specified value can be inserted to maintain
    // the sorted order of the array.
    pos = -(pos+1);

    System.arraycopy(array, pos, array, pos+1, count-pos);
    array[pos] = v;
    count++;
    return true;
  }

  /**
   * Adds all the elements of a provided set to this set if they are not
   * already present.
   * @param that The set of elements to be added.
   * @return the size of the array resizing if any.
   */
  public int addAll(Longs that)
  {
    int newSize=resize(this.count+that.count);

    if (that.count == 0)
    {
      return newSize;
    }

    // Optimize for the case where the two sets are sure to have no overlap.
    if (this.count == 0 || that.array[0] > this.array[this.count-1])
    {
      System.arraycopy(that.array, 0, this.array, this.count, that.count);
      count += that.count;
      return newSize;
    }

    if (this.array[0] > that.array[that.count-1])
    {
      System.arraycopy(this.array, 0, this.array, that.count, this.count);
      System.arraycopy(that.array, 0, this.array, 0, that.count);
      count += that.count;
      return newSize;
    }

    int destPos = binarySearch(this.array, this.count, that.array[0]);
    if (destPos < 0)
    {
      destPos = -(destPos+1);
    }

    // Make space for the copy.
    int aCount = this.count - destPos;
    int aPos = destPos + that.count;
    int aEnd = aPos + aCount;
    System.arraycopy(this.array, destPos, this.array, aPos, aCount);

    // Optimize for the case where there is no overlap.
    if (this.array[aPos] > that.array[that.count-1])
    {
      System.arraycopy(that.array, 0, this.array, destPos, that.count);
      count += that.count;
      return newSize;
    }

    int bPos;
    for ( bPos = 0; aPos < aEnd && bPos < that.count; )
    {
      if ( this.array[aPos] < that.array[bPos] )
      {
        this.array[destPos++] = this.array[aPos++];
      }
      else if ( this.array[aPos] > that.array[bPos] )
      {
        this.array[destPos++] = that.array[bPos++];
      }
      else
      {
        this.array[destPos++] = this.array[aPos++];
        bPos++;
      }
    }

    // Copy any remainder.
    int aRemain = aEnd - aPos;
    if (aRemain > 0)
    {
      System.arraycopy(this.array, aPos, this.array, destPos, aRemain);
      destPos += aRemain;
    }

    int bRemain = that.count - bPos;
    if (bRemain > 0)
    {
      System.arraycopy(that.array, bPos, this.array, destPos, bRemain);
      destPos += bRemain;
    }

    count = destPos;
    return newSize;
  }


  /**
   * Deletes all the elements of a provided set from this set if they are
   * present.
   * @param that The set of elements to be deleted.
   */
  public void deleteAll(Longs that)
  {
    int thisPos, thatPos, destPos;
    for ( destPos = 0, thisPos = 0, thatPos = 0;
          thisPos < count && thatPos < that.count; )
    {
      if ( array[thisPos] < that.array[thatPos] )
      {
        array[destPos++] = array[thisPos++];
      }
      else if ( array[thisPos] > that.array[thatPos] )
      {
        thatPos++;
      }
      else
      {
        thisPos++;
        thatPos++;
      }
    }

    System.arraycopy(array, thisPos, array, destPos, count - thisPos);
    destPos += count - thisPos;

    count = destPos;
  }


  /**
   * Return the number of elements in the set.
   * @return The number of elements in the set.
   */
  public int size()
  {
    return count;
  }

  /**
   * Return the array of longs.
   *
   * @return the array of longs.
   */
  public long[] getArray() {
    return array;
  }

  /**
   * Decode a value from a data input stream.
   * @param dataInputStream The data input stream to read the value from.
   * @throws IOException If an I/O error occurs while reading the value.
   */
  public void decode(DataInputStream dataInputStream)
       throws IOException
  {
    int len = dataInputStream.readInt();
    int count = len/8;
    resize(count);
    for (int i = 0; i < count; i++)
    {
      array[i] = dataInputStream.readLong();
    }
    this.count = count;
  }


  /**
   * Ensures capacity of the internal array for a given number of elements.
   * @param size The internal array will be guaranteed to be at least this
   * size.
   * @return the new size of the array or 0 if it wasn't resized.
   */
  private int resize(int size)
  {
    int increasedSize=0;
    if (array == null)
    {
      array = new long[size];
      increasedSize=size;
    }
    else if (array.length < size)
    {
      // Expand the size of the array in powers of two.
      int newSize = array.length == 0 ? 1 : array.length;
      do
      {
        newSize *= 2;
      } while (newSize < size);

      long[] newBytes = new long[newSize];
      System.arraycopy(array, 0, newBytes, 0, count);
      array = newBytes;
      increasedSize=newSize;
    }
   return increasedSize;
  }


  /**
   * Clears the set leaving it empty.
   */
  public void clear()
  {
    count = 0;
  }



  /**
   * Convert the set to a new array of longs.
   * @return An array of longs.
   */
  public long[] toArray()
  {
    long[] dst = new long[count];

    System.arraycopy(array, 0, dst, 0, count);
    return dst;
  }


  /**
   * {@inheritDoc}
   */
  @Override
  public String toString()
  {
    StringBuilder b = new StringBuilder();
    b.append(count);
    if (count > 0)
    {
      b.append('[');
      b.append(array[0]);
      if (count > 1)
      {
        b.append(':');
        b.append(array[count-1]);
      }
      b.append(']');
    }
    return b.toString();
  }

}
