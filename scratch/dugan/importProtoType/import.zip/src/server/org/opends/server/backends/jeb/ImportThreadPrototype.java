/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import static org.opends.server.loggers.debug.DebugLogger.*;
import org.opends.server.loggers.debug.DebugTracer;
import org.opends.server.types.*;
import org.opends.server.api.DirectoryThread;
import org.opends.messages.Message;
import static org.opends.messages.JebMessages.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.*;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.Transaction;

/**
 * A thread to process import entries from a queue.  Multiple instances of
 * this class process entries from a single shared queue. This is the bare
 * bones no buffering version using  print statements for errors.
 */
public class ImportThreadPrototype extends DirectoryThread
{
  /**
   * The tracer object for the debug logger.
   */
  private static final DebugTracer TRACER = getTracer();


  /*
   * Work queue of work items.
   */
  private BlockingQueue<ImportQueueElementPrototype> queue;


  /**
   * The number of entries imported by this thread.
   */
  private int importedCount = 0;

  private Object syncObj = new Object();


  /**
   * A flag that is set when the thread has been told to stop processing.
   */
  private boolean stopRequested = false;

  private int threadNumber;

  /**
   * Create a new import thread.
   * @param threadNumber A number to identify this thread instance among
   * other instances of the same class.
   */

   public ImportThreadPrototype(ImportContext importContext, int threadNumber) {
    super("Import Worker Thread " + threadNumber);
    queue = importContext.getQueuePrototype();
    this.threadNumber = threadNumber;
  }

  /**
   * Get the number of entries imported by this thread.
   * @return The number of entries imported by this thread.
   */
  public int getImportedCount()
  {
    return importedCount;
  }

  /**
   * Tells the thread to stop processing.
   */
  public void stopProcessing()
  {
    stopRequested = true;
  }

  /**
   * Run the thread. Read from item from queue and give it to the
   * buffer manage, unless told to stop. Once stopped, ask buffer manager
   * to flush and exit.
   *
   */
  public void run()
  {
    try {
      do {
        try {
          ImportQueueElementPrototype element =
                                    queue.poll(1000, TimeUnit.MILLISECONDS);
          if(element != null) {
           process(element);
          }
        }
        catch (InterruptedException e) {
          if (debugEnabled()) {
            TRACER.debugCaught(DebugLogLevel.ERROR, e);
          }
        }
      } while (!stopRequested);
    } catch (Exception e) {
      if (debugEnabled()) {
        TRACER.debugCaught(DebugLogLevel.ERROR, e);
      }
      throw new RuntimeException(e);
    }
  }


  private void process(ImportQueueElementPrototype element)
  {
    Entry entry = element.getEntry();
    EntryID entryID = element.getEntryID();
    ImportContext context = element.getContext();
    Transaction txn = null;
  /* Transaction test
    try {
      txn = context.getEntryContainer().beginTransaction();
    } catch (DatabaseException ex) {
      System.out.println("trans: " + ex.getMessage());
      return;
    }
   */
    if(!processDN2ID(entry, entryID, context, txn))
      return;
    if(!processParent(entry, entryID, context, txn))
      return;
    if(!processID2Entry(entry, entryID, context, txn))
      return;
    if(!procesID2SCEntry(entry, entryID, context, txn))
      return;
    processIndexesEntry(entry, entryID, context, txn);
    /*
    try {
      EntryContainer.transactionCommit(txn);
    } catch(DatabaseException ex) {
      System.out.println("Commit: " + ex.getMessage());
    }
    */
  }




  private void processIndexesEntry(Entry entry, EntryID entryID,
                                   ImportContext context, Transaction txn) {
    LinkedHashMap<AttributeType, AttributeIndex> attrIndexMap =
            context.getAttrIndexMap();
    for(Map.Entry<AttributeType, AttributeIndex> mapEntry :
            attrIndexMap.entrySet()) {
      AttributeType attrType = mapEntry.getKey();
      if(entry.hasUserAttribute(attrType)) {
        AttributeIndex attributeIndex = mapEntry.getValue();
        try {
          if(attributeIndex.equalityIndex != null) {
           insert(attributeIndex.equalityIndex, entry, entryID, txn);
          }
          if(attributeIndex.presenceIndex != null) {
            insert(attributeIndex.presenceIndex, entry, entryID, txn);
          }
          if(attributeIndex.substringIndex != null) {
            insert(attributeIndex.substringIndex, entry, entryID, txn);
          }
          if(attributeIndex.orderingIndex != null) {
             insert(attributeIndex.orderingIndex, entry, entryID, txn);
          }
          if(attributeIndex.approximateIndex != null) {
             insert(attributeIndex.approximateIndex, entry, entryID, txn);
          }
        } catch (DatabaseException ex) {
          System.out.println("Index: " +  ex.getMessage());
        }
      }
    }
  }


  private boolean procesID2SCEntry(Entry entry, EntryID entryID,
                                   ImportContext context, Transaction txn) {
    boolean ret=true;
    Index id2children = context.getEntryContainer().getID2Children();
    Index id2subtree = context.getEntryContainer().getID2Subtree();
    try {
      insert(id2children, entry, entryID, txn);
      insert(id2subtree, entry, entryID, txn);
    } catch (DatabaseException ex) {
      System.out.println("child/subtree: " + ex.getMessage());
      ret=false;
    }
    return ret;
  }

//This one seems to perform better, especially on the 8-cpu test
//machine
 private void
 insert(Index index, Entry entry, EntryID entryID,
        Transaction txn) throws DatabaseException {
  Set<byte[]> keySet = new HashSet<byte[]>();
  index.indexer.indexEntry(txn, entry, keySet);
    if(!index.insert(txn, keySet,  entryID)) {
      System.out.println("Insert failed");
      throw new DatabaseException();
    }
}

 private void
 insertOLD(Index index, Entry entry, EntryID entryID,
        Transaction txn) throws DatabaseException {
  Set<byte[]> keySet = new HashSet<byte[]>();
  index.indexer.indexEntry(txn, entry, keySet);
  for(byte[] key : keySet) {
    if(!index.insert(txn, key,  entryID)) {
      System.out.println("Insert failed");
      throw new DatabaseException();
    }
  }
}

  private boolean processID2Entry(Entry entry, EntryID ID,
                                   ImportContext context, Transaction txn)  {
    boolean ret=true;
    ID2Entry id2entry = context.getEntryContainer().getID2Entry();
    DatabaseEntry key=ID.getDatabaseEntry();
    try {
      DatabaseEntry dbEntry = id2entry.entryData(entry);
      id2entry.putRaw(txn, key, dbEntry);
      importedCount++;
    } catch (DatabaseException ex) {
      System.out.println("DB exception id2entry:" + ex.getMessage());
      ret=false;
    } catch (DirectoryException dirEx) {
      System.out.println("Direxception id2entry:" + dirEx.getMessage());
      ret=false;
    }
    return ret;
  }

  private boolean processParent(Entry entry, EntryID entryID,
                                ImportContext context, Transaction txn) {
    EntryID parentID = null;
    DN entryDN = entry.getDN();
    DN parentDN =
            context.getEntryContainer().getParentWithinBase(entryDN);
    DN2ID dn2id = context.getEntryContainer().getDN2ID();
    if (parentDN != null) {
      try {
        parentID = context.getParentID(parentDN, dn2id, txn);
      } catch (DatabaseException ex) {
        System.out.println("parentID failed");
      }
      if (parentID == null) {
        try {
          dn2id.remove(txn, entryDN);
        } catch (DatabaseException ex) {
          System.out.println("delete DN failed");
        }
        Message msg =
                ERR_JEB_IMPORT_PARENT_NOT_FOUND.get(parentDN.toString());
        context.getLDIFReader().rejectLastEntry(msg);
        return false;
      }
    }
    ArrayList<EntryID> IDs;
    if (parentDN != null && context.getParentDN() != null &&
            parentDN.equals(context.getParentDN())) {
      IDs = new ArrayList<EntryID>(context.getIDs());
      IDs.set(0, entryID);
    }
    else {
      IDs = new ArrayList<EntryID>(entryDN.getNumComponents());
      IDs.add(entryID);
      if (parentID != null)
      {
        IDs.add(parentID);
        EntryContainer ec = context.getEntryContainer();
        for (DN dn = ec.getParentWithinBase(parentDN); dn != null;
             dn = ec.getParentWithinBase(dn)) {
          try {
            EntryID nodeID = dn2id.get(txn, dn);
            IDs.add(nodeID);
          } catch (DatabaseException ex) {
            System.out.println("dn2id two failed");
            return false;
          }
        }
      }
    }
    context.setParentDN(parentDN);
    context.setIDs(IDs);
    entry.setAttachment(IDs);
    return true;
  }



  private boolean processDN2ID(Entry entry, EntryID entryID,
                               ImportContext context, Transaction txn) {
    boolean inserted;
    DN entryDN = entry.getDN();
    try {
      DN2ID dn2id = context.getEntryContainer().getDN2ID();
      inserted = dn2id.insert(txn, entryDN, entryID);
      if(!inserted) {
        Message msg = WARN_JEB_IMPORT_ENTRY_EXISTS.get();
        context.getLDIFReader().rejectLastEntry(msg);
      }
    } catch(DatabaseException ex) {
      System.out.println("DN2ID insert error: " + ex.getMessage());
      inserted=false;
    }
    context.removePending(entryDN);
    return inserted;
  }

}
