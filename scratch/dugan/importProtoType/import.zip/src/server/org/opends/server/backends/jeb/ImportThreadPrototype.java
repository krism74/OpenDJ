/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import static org.opends.server.loggers.debug.DebugLogger.*;
import org.opends.server.loggers.debug.DebugTracer;
import org.opends.server.types.DebugLogLevel;
import org.opends.server.types.Entry;
import org.opends.server.types.DirectoryException;
import org.opends.server.api.DirectoryThread;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.Set;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.DatabaseEntry;

/**
 * A thread to process import entries from a queue.  Multiple instances of
 * this class process entries from a single shared queue. This is the bare
 * bones no buffering version.
 */
public class ImportThreadPrototype extends DirectoryThread
{
  /**
   * The tracer object for the debug logger.
   */
  private static final DebugTracer TRACER = getTracer();


  /**
   * The import context of this thread.
   */
  private ImportContext importContext;


  /*
   * Work queue of work items.
   */
  private BlockingQueue<ImportQueueElementPrototype> queue;


  /**
   * The number of entries imported by this thread.
   */
  private int importedCount = 0;


  /**
   * A flag that is set when the thread has been told to stop processing.
   */
  private boolean stopRequested = false;


  /**
   * Create a new import thread.
   * @param importContext The import context of the thread.
   * @param threadNumber A number to identify this thread instance among
   * other instances of the same class.
   */

   public ImportThreadPrototype(ImportContext importContext,
                                int threadNumber) {
    super("Import Worker Thread " + threadNumber);
    this.importContext=importContext;
    queue = importContext.getQueuePrototype();
  }

  /**
   * Get the number of entries imported by this thread.
   * @return The number of entries imported by this thread.
   */
  public int getImportedCount()
  {
    return importedCount;
  }

  /**
   * Tells the thread to stop processing.
   */
  public void stopProcessing()
  {
    stopRequested = true;
  }

  /**
   * Run the thread. Read from item from queue and give it to the
   * buffer manage, unless told to stop. Once stopped, ask buffer manager
   * to flush and exit.
   *
   */
  public void run()
  {
    try {
      do {
        try {
          ImportQueueElementPrototype element =
                                    queue.poll(1000, TimeUnit.MILLISECONDS);
          if(element != null) {
           process(element);
          }
        }
        catch (InterruptedException e) {
          if (debugEnabled()) {
            TRACER.debugCaught(DebugLogLevel.ERROR, e);
          }
        }
      } while (!stopRequested);
    } catch (Exception e) {
      if (debugEnabled()) {
        TRACER.debugCaught(DebugLogLevel.ERROR, e);
      }
      throw new RuntimeException(e);
    }
  }

  private void process(ImportQueueElementPrototype element)
          throws DatabaseException {
    if(element.getID2Entry() != null) {
      DatabaseEntry key=element.getIDKey();
      Entry entry=element.getEntry();
      importedCount++;
      try {
      DatabaseEntry dbEntry = element.getID2Entry().entryData(entry);
      element.getID2Entry().putRaw(null, key, dbEntry);
      } catch (DirectoryException ex) {
        System.out.println("process id2entry:" + ex.getMessage());
        return;
      }
    } else if(element.getVLVIndex() != null)  {
      System.out.println("vlv not supported");
    } else {
      Index index = element.getIndex();
      Set<byte[]> keys=index.indexer.getIndexKeys(element);
      for(byte[] key : keys) {
        if(!index.insert(null, key,  element.getEntryID())) {
          System.out.println("Insert failed");
          throw new DatabaseException();
        }
      }
    }
  }

}
