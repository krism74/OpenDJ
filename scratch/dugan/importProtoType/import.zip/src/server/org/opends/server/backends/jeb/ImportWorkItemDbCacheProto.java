package org.opends.server.backends.jeb;

import com.sleepycat.je.DatabaseEntry;

import java.util.ArrayList;
import java.util.List;

import org.opends.server.types.Attribute;

public class ImportWorkItemDbCacheProto implements ImportWorkItem {

  //Item is id2entry.
  private boolean id2entry=false;

  //Item is index.
  private Indexer indexer;

  //Used by id2entry work item. Database key and database entry representations.
  private DatabaseEntry key, entry;

  //Used by index work items. Array list of ids.
  private ArrayList<EntryID> IDs;

  //Used by index work items. List off attributes.
  private List<Attribute> attrList;
  private boolean maintainCount = false;
  private int indexLimit = 0;
  private ImportJobDBCacheSize job;

  /**
   * Construct a work item using specified attribute list and array of IDs. Used
   * when index a general index.
   *
   * @param indexer The index to insert into.
   * @param attrList List of attributes to generate keys for.
   * @param IDs IDs to insert into DB.
   */
  private ImportWorkItemDbCacheProto(Indexer indexer, List<Attribute> attrList,
                           ArrayList<EntryID> IDs, int indexLimit,
                           ImportJobDBCacheSize job) {
   this.indexer=indexer;
   this.attrList=attrList;
   this.IDs=IDs;
   this.indexLimit = indexLimit;
   this.job = job;
  }

  /**
   * Construct work item using specified array of IDs. Used when index is
   * id2children/id2subtree.
   *
   * @param indexer The index to insert into.
   * @param IDs List of IDs to insert into DB.
   */
  private ImportWorkItemDbCacheProto(Indexer indexer, ArrayList<EntryID> IDs,
                                     int indexLimit, ImportJobDBCacheSize job) {
    this.indexer=indexer;
    this.IDs=IDs;
    this.indexLimit = indexLimit;
    this.maintainCount = true;
    this.job = job;
  }

  /**
   * Construct work item using specified database key and entry. Used when
   * work item is id2entry.
   *
   * @param key The database key to use.
   * @param entry The database entry to create.
   */
  private ImportWorkItemDbCacheProto(DatabaseEntry key,
                           DatabaseEntry entry, ImportJobDBCacheSize job) {
    this.key = key;
    this.id2entry = true;
    this.entry = entry;
    this.job = job;
  }

  /**
   * Create work item when index is a general index.
   * @param indexer The index to insert into.
   * @param attrList List of attributes to generate keys for.
   * @param IDs IDs to insert into DB.
   * @return ImportWorkItem representing a general index work item.
   */
  public static ImportWorkItemDbCacheProto
  decode(Indexer indexer, List<Attribute> attrList, ArrayList<EntryID> IDs,
         int indexLimit, ImportJobDBCacheSize job) {
    return new ImportWorkItemDbCacheProto(indexer, attrList, IDs,
                                          indexLimit, job);
  }

  /**
   * Create work item when ID2ENTRY is the work item.
   * @param key The database key to use.
   * @param entry The database entry to create.
   * @return ImportWorkItem representing a ID2ENTRY work item.
   */
  public static
  ImportWorkItemDbCacheProto decode(DatabaseEntry key, DatabaseEntry entry,
                                    ImportJobDBCacheSize job) {
    return new ImportWorkItemDbCacheProto(key, entry, job);
  }

  /**
   * Create a work item that uses a array list of IDs to get a key (ID2CHILDREN/
   * ID2SUBTREE).
   *
   * @param indexer  The index to insert into.
   * @param IDs IDs to insert into DB.
   * @return ImportWorkItem representing a index work item.
   */
  public static
  ImportWorkItemDbCacheProto decode(Indexer indexer, ArrayList<EntryID> IDs,
                                    int indexLimit, ImportJobDBCacheSize job)  {
    return new ImportWorkItemDbCacheProto(indexer, IDs, indexLimit, job);
  }


  /**
   * Return the ID2NETRY object.
   *
   * @return The ID2ENTRY object.
   */
  public boolean isID2Entry() {
    return id2entry;
  }

  /**
   * Return the index to insert into.
   *
   * @return The index to insert into.
   */
  public Indexer getIndexer() {
    return indexer;
  }

  /**
   * Return the key to use in the insert in database format.
   *
   * @return The key.
   */
  public DatabaseEntry getIDKey() {
    return key;
  }

  /**
   * Return the entry to add in database format.
   *
   * @return The entry to add.
   */
  public DatabaseEntry getEntry() {
    return entry;
  }

  /**
   * Return the entry ID (ID of index 0 of the ID list).
   *
   * @return The entry ID.
   */
  public EntryID getEntryID() {
    return IDs.get(0);
  }

  /**
   * Return the list of IDs.
   *
   * @return The ID list.
   */
  public ArrayList<EntryID> getIDs() {
    return IDs;
  }

  /**
   * Return the list of attributes.
   *
   * @return The attribute list.
   */
  public List<Attribute> getAttrList() {
    return attrList;
  }

  /**
   * VLV Index not supported in prototype.
   *
   * @return null.
   */
  public VLVIndex getVLVIndex() {
    return null;
  }

  public int getIndexLimit() {
    return indexLimit;
  }

  public boolean maintainCount() {
    return maintainCount;
  }

  public ImportKeyCache getJob() {
    return job;
  }

  public ImportMemoryBudgetProto getMemoryBudget() {
    return null;
  }

  public void setMemoryBudget(ImportMemoryBudgetProto memBudget) {

  }
}
