/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */
package org.opends.server.backends.jeb;

import org.opends.server.api.DirectoryThread;
import static org.opends.server.loggers.debug.DebugLogger.debugEnabled;
import static org.opends.server.loggers.debug.DebugLogger.getTracer;
import org.opends.server.loggers.debug.DebugTracer;
import org.opends.server.types.DebugLogLevel;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class ImportThreadDbCacheSize extends DirectoryThread {
  private static final DebugTracer TRACER = getTracer();


  private  BlockingQueue<ImportWorkItemDbCacheProto> queue;

  private boolean stopRequested = false;

  private ImportBufferMgrProto bufferMgr;
  private long keyBytes=0, valBytes=0, dbEntries=0;

  public
  ImportThreadDbCacheSize(BlockingQueue<ImportWorkItemDbCacheProto> queue,
                           long budgetLimit, int threadNumber,
                           ImportJobDBCacheSize job) {
    super("Import Worker Thread " + threadNumber);
    this.queue = queue;
    this.bufferMgr=new ImportBufferMgrProto(job);
  }

  public void stopProcessing() {
    stopRequested = true;
  }

  public int getNumDBEntries() {
    return bufferMgr.getNumDBEntries();
  }

  public long getKeyBytes() {
    return bufferMgr.getKeyBytes();
  }

  public long getValBytes() {
    return bufferMgr.getValBytes();
  }

  public void run()
  {
    try {
      do {
        try {
          ImportWorkItemDbCacheProto item =
                       queue.poll(1000, TimeUnit.MILLISECONDS);
          if (item != null) {
              bufferMgr.add(item);
          }
        } catch (InterruptedException e) {
          if (debugEnabled()) {
            TRACER.debugCaught(DebugLogLevel.ERROR, e);
          }
        }
      } while (!stopRequested);
        bufferMgr.flushDbCache();
    } catch (Exception e) {
      if (debugEnabled()) {
        TRACER.debugCaught(DebugLogLevel.ERROR, e);
      }
      throw new RuntimeException(e);
    }
  }
}
