/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */
package org.opends.server.backends.jeb;

import org.opends.server.util.args.LDAPConnectionArgumentParser;
import org.opends.server.util.args.StringArgument;
import static org.opends.server.util.StaticUtils.wrapText;
import static org.opends.server.util.StaticUtils.getExceptionMessage;
import static org.opends.server.util.StaticUtils.stackTraceToSingleLineString;
import static org.opends.server.util.ServerConstants.MAX_LINE_WIDTH;
import org.opends.server.core.DirectoryServer;
import org.opends.server.core.CoreConfigManager;
import org.opends.server.types.*;
import org.opends.server.config.ConfigException;
import org.opends.server.config.ConfigEntry;
import org.opends.server.config.ConfigConstants;
import static org.opends.server.loggers.ErrorLogger.logError;
import static org.opends.server.loggers.ErrorLogger.addErrorLogPublisher;
import static org.opends.server.loggers.debug.DebugLogger.debugEnabled;
import org.opends.server.loggers.ThreadFilterTextErrorLogPublisher;
import org.opends.server.loggers.TextWriter;
import org.opends.server.admin.std.server.BackendCfg;
import org.opends.server.admin.std.server.RootCfg;
import org.opends.server.admin.std.server.LocalDBBackendCfg;
import org.opends.server.admin.std.server.LocalDBIndexCfg;
import org.opends.server.admin.std.meta.LocalDBIndexCfgDefn;
import org.opends.server.admin.server.ServerManagementContext;
import org.opends.server.api.Backend;
import org.opends.server.api.ErrorLogPublisher;
import org.opends.server.api.plugin.PluginType;
import org.opends.messages.Message;
import static org.opends.messages.ConfigMessages.ERR_CONFIG_BACKEND_CANNOT_GET_CONFIG_BASE;
import static org.opends.messages.ToolMessages.ERR_CANNOT_LOAD_CONFIG;
import static org.opends.messages.ToolMessages.ERR_CANNOT_LOAD_SCHEMA;
import static org.opends.messages.ToolMessages.ERR_SERVER_BOOTSTRAP_ERROR;
import static org.opends.messages.ToolMessages.ERR_LDIFIMPORT_CANNOT_READ_FILE;
import static org.opends.messages.ToolMessages.ERR_CANNOT_INITIALIZE_CORE_CONFIG;
import static org.opends.messages.ToolMessages.ERR_LDIFIMPORT_CANNOT_INITIALIZE_PLUGINS;
import static org.opends.messages.ToolMessages.ERR_LDIFIMPORT_CANNOT_INITIALIZE_PWPOLICY;
import static org.opends.messages.ToolMessages.ERR_CANNOT_INITIALIZE_CRYPTO_MANAGER;

import java.io.PrintStream;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicLong;


public class ImportDBCacheSize {

  private int ldifReadSize, totalSize;
  private LDAPConnectionArgumentParser  argParser;
  private StringArgument backendID;
  private   ErrorLogPublisher errorLogPublisher;
  private PrintStream out,  err;

  public ImportDBCacheSize(LDAPConnectionArgumentParser argParser,
                           StringArgument backendID,
                           int ldifReadSize, int totalSize,
                           PrintStream out, PrintStream err,
                           ErrorLogPublisher errorLogPublisher) {
    this.ldifReadSize = ldifReadSize;
    this.totalSize = totalSize;
    this.argParser = argParser;
    this.backendID = backendID;
    this.errorLogPublisher = errorLogPublisher;
    this.out = out;
    this.err = err;
  }

  public int process(PrintStream out,PrintStream err,
                     StringArgument configClass,
                     StringArgument configFile,
                     StringArgument ldifFiles) {

    if (argParser.connectionArgumentsPresent()) {
      return 0;
    }
    DirectoryServer directoryServer = DirectoryServer.getInstance();
    try
    {
      DirectoryServer.bootstrapClient();
      DirectoryServer.initializeJMX();
    }
    catch (Exception e)
    {
      Message message = ERR_SERVER_BOOTSTRAP_ERROR.get(
              getExceptionMessage(e));
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    try
    {
      directoryServer.initializeConfiguration(configClass.getValue(),
              configFile.getValue());
    }
    catch (InitializationException ie)
    {
      Message message = ERR_CANNOT_LOAD_CONFIG.get(ie.getMessage());
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    catch (Exception e)
    {
      Message message = ERR_CANNOT_LOAD_CONFIG.get(getExceptionMessage(e));
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }

    // Initialize the Directory Server schema elements.
    try
    {
      directoryServer.initializeSchema();
    }
    catch (ConfigException ce)
    {
      Message message = ERR_CANNOT_LOAD_SCHEMA.get(ce.getMessage());
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    catch (InitializationException ie)
    {
      Message message = ERR_CANNOT_LOAD_SCHEMA.get(ie.getMessage());
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    catch (Exception e)
    {
      Message message = ERR_CANNOT_LOAD_SCHEMA.get(getExceptionMessage(e));
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }

      // Initialize the Directory Server core configuration.
      try
      {
        CoreConfigManager coreConfigManager = new CoreConfigManager();
        coreConfigManager.initializeCoreConfig();
      }
      catch (ConfigException ce)
      {
        Message message = ERR_CANNOT_INITIALIZE_CORE_CONFIG.get(
                ce.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (InitializationException ie)
      {
        Message message = ERR_CANNOT_INITIALIZE_CORE_CONFIG.get(
                ie.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (Exception e)
      {
        Message message = ERR_CANNOT_INITIALIZE_CORE_CONFIG.get(
                getExceptionMessage(e));
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }


    // Initialize the Directory Server crypto manager.
    try
    {
      directoryServer.initializeCryptoManager();
    }
    catch (ConfigException ce)
    {
      Message message = ERR_CANNOT_INITIALIZE_CRYPTO_MANAGER.get(
              ce.getMessage());
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    catch (InitializationException ie)
    {
      Message message = ERR_CANNOT_INITIALIZE_CRYPTO_MANAGER.get(
              ie.getMessage());
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }
    catch (Exception e)
    {
      Message message = ERR_CANNOT_INITIALIZE_CRYPTO_MANAGER.get(
              getExceptionMessage(e));
      err.println(wrapText(message, MAX_LINE_WIDTH));
      return 1;
    }


      // Initialize all the password policy information.
      try
      {
        directoryServer.initializePasswordPolicyComponents();
      }
      catch (ConfigException ce)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PWPOLICY.get(
                ce.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (InitializationException ie)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PWPOLICY.get(
                ie.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (Exception e)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PWPOLICY.get(
                getExceptionMessage(e));
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }

      // Make sure that the Directory Server plugin initialization is performed.
      try
      {
        HashSet<PluginType> pluginTypes = new HashSet<PluginType>(1);
        pluginTypes.add(PluginType.LDIF_IMPORT);
        directoryServer.initializePlugins(pluginTypes);
      }
      catch (ConfigException ce)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PLUGINS.get(
                ce.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (InitializationException ie)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PLUGINS.get(
                ie.getMessage());
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }
      catch (Exception e)
      {
        Message message = ERR_LDIFIMPORT_CANNOT_INITIALIZE_PLUGINS.get(
                getExceptionMessage(e));
        err.println(wrapText(message, MAX_LINE_WIDTH));
        return 1;
      }


    // FIXME -- Install a custom logger to capture information about the
    // state of the import.
    try
    {
      errorLogPublisher =
              new ThreadFilterTextErrorLogPublisher(Thread.currentThread(),
                      new TextWriter.STREAM(out));
      addErrorLogPublisher(errorLogPublisher);

    }
    catch(Exception e)
    {
      err.println("Error installing the custom error logger: " +
              stackTraceToSingleLineString(e));
    }

    LDIFImportConfig importConfig =  null;
    if (ldifFiles.isPresent())
    {
      ArrayList<String> fileList = new ArrayList<String>(ldifFiles.getValues());
      int badFileCount = 0;
      for (String pathname : fileList)
      {
        File f = new File(pathname);
        if (!f.canRead())
        {
          Message message = ERR_LDIFIMPORT_CANNOT_READ_FILE.get(pathname);
          logError(message);
          badFileCount++;
        }
      }
      if (badFileCount > 0) return 1;
      importConfig = new LDIFImportConfig(fileList);
    }
    RootCfg root = ServerManagementContext.getInstance().getRootConfiguration();

    BackendCfg cfg = null;
    try {
      cfg = root.getBackend(backendID.getValue());

    } catch (Exception ex) {
     err.println("Error getting backend config");
    }
    LocalDBBackendCfg cfgBk = (LocalDBBackendCfg)cfg;
    ImportJobDBCacheSize job = new ImportJobDBCacheSize(importConfig, cfgBk,
            ldifReadSize, totalSize);

    try {
     job.importLDIF();
    } catch (Exception ex) {
      err.println("Error estimating DB cache size from ldif file");
    }

    return 1;
  }

}
