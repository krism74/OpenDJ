/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import java.util.*;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import org.opends.server.types.ByteArray;
import static org.opends.server.loggers.ErrorLogger.logError;
import org.opends.messages.Message;
import static org.opends.messages.JebMessages.*;

/**
 * The buffer manager class of the import prototype. Each import worker thread
 * has one of these that manages a set of buffers.
 */

public class ImportBufferMgrProto {

  //The count of entries inserted into the ID2ENTRY DB by this buffer manager.

  private int entryInsertCount = 0;

  //The memory budget class to keep track of the memory used by the buffers.
  private ImportMemoryBudgetProto memBudget;

  //Map of hashmaps keyed by the index. Each index has a hashmap of keys
  //containing the Longs to be inserted into the respective index.
  private HashMap<Index, HashMap<ByteArray, Longs>> indexerMap =
          new HashMap<Index, HashMap<ByteArray, Longs>>();

  //The ID2ENTRY database when the work item contains an ID2ENTRY object.
  private ID2Entry id2entry;

  //Used to print out a log message when this thread has started flushing.
  private int underBudgetFlushes=0;

  //Grace value that is added to current memory usage so this thread doesn't
  //spend all of its time flushing.
  private long grace;

  //The next index to start flushing from. Used to try and flush from all of the
  //indexes.
  private Index nextFlushed;

  long keyTotBytes = 0, valTotBytes = 0;
  int numDBEntries = 0;
  private ImportJobProto jobProt;
  private ImportJobDBCacheSize job;
  private byte[][] subBuf;
  private ArrayList<ByteArray> keyList = new ArrayList<ByteArray>();

  //Map of hashmaps keyed by the index. Each index has a hashmap of keys
  //containing the Longs to be inserted into the respective index.
  private HashMap<Indexer, HashMap<ByteArray, Longs>> dbCacheIndexerMap =
          new HashMap<Indexer, HashMap<ByteArray, Longs>>();

  /**
   * Create a new buffer manager instance using the specified memory budget and
   * import context. Used when there was a global memory budget class.
   *
   * @param memBudget The memory budget to be used by this buffer manager.
   * @param importContext The import context.
   */
  public ImportBufferMgrProto(ImportMemoryBudgetProto memBudget,
                         ImportContext importContext) {
    this.memBudget=memBudget;
    this.id2entry=importContext.getEntryContainer().getID2Entry();
  }

  public ImportBufferMgrProto(ImportJobDBCacheSize job) {
    this.job = job;
    int subLen = job.getIndexSubStr();
    subBuf = new byte[subLen][];
    for(int i = 0; i < subLen; i++) {
      subBuf[i] = new byte[i+1];
    }
  }
  /**
   * Create a new buffer manager using the specified budget limit and import
   * context.
   *
   * @param budgetLimit The budget limit to use.
   * @param importContext The import context.
   */
  public ImportBufferMgrProto(long budgetLimit, ImportContext importContext,
                              ImportJobProto job) {
    this.memBudget=new ImportMemoryBudgetProto(budgetLimit);
    //20 percent seems to work.
    this.grace = (budgetLimit * 20) / 100;
    this.id2entry=importContext.getEntryContainer().getID2Entry();
    subBuf = new byte[10][];
    for(int i = 0; i < 10; i++) {
      subBuf[i] = new byte[i+1];
    }
  }

   public ImportBufferMgrProto() {  }

  /**
   * Add a work item to the buffers, but check if we need to flush first.
   *
   * @param item The work item read from the queue.
   * @throws DatabaseException If a DB error occurs.
   */
  public void add(ImportWorkItemProto item) throws DatabaseException  {
    if(item.getID2Entry() != null) {
      addId2Entry(item);
    } else {
      if(memBudget.overBudgetLimit(0)) {
        underBudgetFlushes++;
        getUnderBudget(grace);
      }
      addBuffer(item);
    }
  }

  private void addId2Entry(ImportWorkItemProto item)
          throws DatabaseException {
    DatabaseEntry key=item.getIDKey();
    DatabaseEntry entry=item.getEntry();
    entryInsertCount++;
    id2entry.putRaw(null, key, entry);
  }


  /**
   * Attempt to add a work item to the buffers or ID2ENTRY DB. See comments.
   *
   * @param item The work item to add.
   * @throws DatabaseException If a DB error occurs.
   */
  private void addBuffer(ImportWorkItemProto item) throws DatabaseException {
    if(item.getVLVIndex() != null)  {
      System.out.println("vlv not supported");
    } else {
      //Gather the index info -- index, entry limit and maintain index
      //count boolean.
      Index index = item.getIndex();
      int eLimit=index.getIndexEntryLimit();
      boolean maintainCount = index.getMaintainCount();
      //Get the key set from the index indexer.
      item.setMemoryBudget(memBudget);
     // Set<byte[]> keys=index.indexer.indexImportWorkItem(null, item);
       index.indexer.indexImportWorkItem(item, subBuf, keyList);
      HashMap<ByteArray, Longs> keyHashMap;
      //Get the key hash map from the index map using the index object as the
      //key. If it doesn't exist create it and add it to the index map.
      if(indexerMap.containsKey(index)) {
        keyHashMap = indexerMap.get(index);
      } else {
        keyHashMap = new HashMap<ByteArray, Longs>();
        memBudget.addMemoryUsageHashMap();
        indexerMap.put(index, keyHashMap);
        memBudget.addMemoryUsageHashMapEntry();
      }
      //Iterate over each key checking if each key is in the key hash map.
      // If it is, add the items entry ID to a existing Longs class or
      // create a new Longs class and add a hash entry for that key to the
      //key hash map.
   //   for(byte[] rawKey : keys) {
   //     ByteArray key = new ByteArray(rawKey);
      for(ByteArray key : keyList) {
        Longs bufferedLongs=keyHashMap.get(key);
        if(bufferedLongs != null) {
          int added;
          if(maintainCount) {
            added=bufferedLongs.addEntryIDCount(item.getEntryID(), eLimit);
          } else {
            added=bufferedLongs.addEntryID(item.getEntryID(), eLimit);
          }
          //Added is the new size of the Longs array if it was increased.
          memBudget.addMemoryUsageLong(added);
        } else {
          Longs bufLongs=new Longs(item.getEntryID());
          keyHashMap.put(key, bufLongs);
          //Add to the memory budget the newly allocated stuctures.
          memBudget.addMemoryUsage(key.array(), bufLongs.getArray().length);
        }
      }
      keyList.clear();
    }
  }

  /**
   * Flush the key hash maps until the memory used is under budget by some
   * extra amount (grace). Tries to rotate through the indexes so a different
   * set is flushed each time.
   *
   * @param grace The extra amount of memory to get under budget by.
   * @throws DatabaseException If a DB error occurs.
   */
  private  void getUnderBudget(long grace) throws DatabaseException {
    while(true) {
      Iterator<Index>  indexIter=getStartIndex();
      while (indexIter.hasNext()) {
        Index index = indexIter.next();
        //Check if under budget, if so mark the next index to start from.
        if(!memBudget.overBudgetLimit(grace)) {
          nextFlushed=index;
          return;
        }
        flushKeyMap(index);
      }
      //Ran off the end the index map. Reset and start from the beginning.
      nextFlushed=null;
    }
  }

  /**
   * Flush the complete key hash map for an index to DB.
   *
   * @param index  The index to flush to.
   * @throws DatabaseException If a DB error occurs.
   */
  private void flushKeyMap(Index index) throws DatabaseException {

    HashMap<ByteArray, Longs> keyHashMap = indexerMap.get(index);
    Set<ByteArray> keys = keyHashMap.keySet();
    Iterator<ByteArray> iter = keys.iterator() ;
    while(iter.hasNext()) {
      ByteArray key = iter.next();
      Longs bufLongs=keyHashMap.get(key);
      //If key Long value is undefined leave it. It will be inserted at the
      //end of run flush.
      if(bufLongs.isDefined()) {
        //Save the old length of the Longs array.
        int oldLen = bufLongs.getArray().length;
        //Insert it into the index.
        bufLongs =
              index.insertLongs(null, new DatabaseEntry(key.array()), bufLongs);
        //If the Longs went undefined adjust the memory budget or remove it
        //from the iterator and adjust the memory for the removed key,
        //Longs array and Longs class..
        if(!bufLongs.isDefined()) {
          memBudget.removeMemoryUsage(oldLen);
        } else {
          memBudget.removeMemoryUsage(key.array(), bufLongs.getArray().length);
          iter.remove();
        }
      }
    }
  }

  /**
   * Return an iterator pointing to the next index to start flushing at. If the
   * next flushed object is null start from the beginning of the map.
   *
   * @return Iterator of next index to start flushing at.
   */
  private Iterator<Index> getStartIndex()  {
    Iterator<Index> indexIter = indexerMap.keySet().iterator();
    if(nextFlushed != null) {
      while (indexIter.hasNext()) {
        if(indexIter.next() != nextFlushed) {
          continue;
        }
        break;
      }
    }
    return indexIter;
  }

  /**
   * Flush all of the key hash maps of each index to the DB.
   *
   * @throws DatabaseException If a DB error occurs.
   */
  public void flush()
          throws DatabaseException {
    Message message;
    if(underBudgetFlushes > 0) {
      message = INFO_JEB_INDEX_INTER_BUFFER_FLUSHES.get(underBudgetFlushes);
    } else {
      message = INFO_JEB_INDEX_BUFFER_FLUSHES.get();
    }
    logError(message);
    for(Map.Entry<Index, HashMap<ByteArray, Longs>> mapEntry :
            indexerMap.entrySet()) {
      Index index = mapEntry.getKey();
      HashMap<ByteArray, Longs> keyHashMap = mapEntry.getValue();
      for(ByteArray key : keyHashMap.keySet()) {
        Longs bufLongs=keyHashMap.get(key);
        index.insertLongs(null, new DatabaseEntry(key.array()), bufLongs);
      }
      keyHashMap.clear();
    }
  }

  /**
   * Return the number of id2entry inserts.
   *
   * @return The entry insert count.
   */
  public int getInsertCount(){
    return entryInsertCount;
  }

  public void add(ImportWorkItemDbCacheProto item) throws DatabaseException  {
    if(item.isID2Entry()) {
      numDBEntries++;
      keyTotBytes += item.getIDKey().getData().length;
      valTotBytes += item.getEntry().getData().length;
    } else {
      if(numDBEntries % 25000 == 0) {
        flushDbCache();
      }
      Indexer indexer = item.getIndexer();
      int eLimit=item.getIndexLimit();
      boolean maintainCount = item.maintainCount();
      //Set<byte[]> keys=indexer.indexImportWorkItem(null, item);
      indexer.indexImportWorkItem(item, subBuf, keyList);
      HashMap<ByteArray, Longs> keyHashMap;
      if(dbCacheIndexerMap.containsKey(indexer)) {
        keyHashMap = dbCacheIndexerMap.get(indexer);
      } else {
        keyHashMap = new HashMap<ByteArray, Longs>();
        dbCacheIndexerMap.put(indexer, keyHashMap);
      }
      for(ByteArray key : keyList) {
    //  for(byte[] rawKey : keys) {
     //   ByteArray key = new ByteArray(rawKey);
        Longs bufferedLongs=keyHashMap.get(key);
        if(bufferedLongs != null) {
          if(maintainCount) {
            bufferedLongs.addEntryIDCountDBCache(item.getEntryID(), eLimit);
          } else {
            bufferedLongs.addEntryIDDBCache(item.getEntryID(), eLimit);
          }
        } else {
          Longs bufLongs=new Longs();
          bufLongs.incrIDCountOnly();
          keyHashMap.put(key, bufLongs);
        }
      }
      keyList.clear();
    }
  }

    public void flushDbCache() {
    for(Map.Entry<Indexer, HashMap<ByteArray, Longs>> mapEntry :
            dbCacheIndexerMap.entrySet()) {
      Indexer indexer = mapEntry.getKey();
      HashMap<ByteArray, Longs> keyHashMap = mapEntry.getValue();
      for(ByteArray key : keyHashMap.keySet()) {
        Longs bufLongs=keyHashMap.get(key);
        job.doIds(indexer, key, bufLongs);
      }
      keyHashMap.clear();
    }
  }

  public int getNumDBEntries() {
    return numDBEntries;
  }

  public long getKeyBytes() {
    return keyTotBytes;
  }

  public long getValBytes() {
    return valTotBytes;
  }
}
