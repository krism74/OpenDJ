/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import org.opends.server.types.*;
import org.opends.server.loggers.debug.DebugTracer;
import static org.opends.server.loggers.debug.DebugLogger.getTracer;
import static org.opends.server.loggers.debug.DebugLogger.debugEnabled;
import static org.opends.server.loggers.ErrorLogger.logError;
import org.opends.server.admin.std.server.LocalDBBackendCfg;
import org.opends.server.util.LDIFReader;
import org.opends.server.util.StaticUtils;
import org.opends.server.util.LDIFException;
import org.opends.server.util.RuntimeInformation;
import static org.opends.server.util.DynamicConstants.BUILD_ID;
import static org.opends.server.util.DynamicConstants.REVISION_NUMBER;
import org.opends.server.config.ConfigException;
import org.opends.server.core.DirectoryServer;
import org.opends.messages.Message;
import org.opends.messages.JebMessages;
import static org.opends.messages.JebMessages.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.util.*;
import java.io.IOException;

import com.sleepycat.je.*;

/**
 * Import job for the proto type. Drop-in replacement for old import job.
 * There might still be some merge cruft remaining. Doesn't do migrate or
 * merging.
 */

public class ImportJobProto implements ImportKeyCache,
                            Thread.UncaughtExceptionHandler {


  /**
   * The tracer object for the debug logger.
   */
  private static final DebugTracer TRACER = getTracer();

  /**
   * The JE backend configuration.
   */
  private LocalDBBackendCfg config;

  /**
   * The root container used for this import job.
   */
  private RootContainer rootContainer;

  /**
   * The LDIF import configuration.
   */
  private LDIFImportConfig ldifImportConfig;

  /**
   * The LDIF reader.
   */
  private LDIFReader reader;

  /**
   * Map of base DNs to their import context.
   */
  private LinkedHashMap<DN,ImportContext> importMap =
      new LinkedHashMap<DN, ImportContext>();


  /**
   * The maximum number of parent ID values that we will remember.
   */
  private static final int PARENT_ID_MAP_SIZE = 50;

  /**
   * Map of likely parent entry DNs to their entry IDs.
   */
  private HashMap<DN,EntryID> parentIDMap =
       new HashMap<DN,EntryID>(PARENT_ID_MAP_SIZE);

  /**
   * The number of entries imported.
   */
  private int importedCount;

  /**
   * The number of milliseconds between job progress reports.
   */
  private long progressInterval = 10000;

  /**
   * The progress report timer.
   */
  private Timer timer;

  //Progress task.
  private TimerTask progressTask;

  //Thread array.
  private CopyOnWriteArrayList<ImportThreadProto> threads;

  //Objectclass attribute type.
  private AttributeType ocType;

  private ConcurrentHashMap<ByteArray, ByteArray> keyMap =
          new ConcurrentHashMap<ByteArray, ByteArray>();

  private long keyHit = 0;
  /**
   * Create a new import job with the specified ldif import config.
   *
   * @param ldifImportConfig The LDIF import config.
   */
  public ImportJobProto(LDIFImportConfig ldifImportConfig)
  {
    this.ldifImportConfig = ldifImportConfig;
    this.threads = new CopyOnWriteArrayList<ImportThreadProto>();
    ocType = DirectoryServer.getObjectClassAttributeType();
  }

  /**
   * Start worker threads using the specified memory budget limit.
   *
   * @param budgetLimit The memory budget limit for each thread.
   * @throws DatabaseException If if DB error occurs.
   */
 private void startWorkerThreads(long budgetLimit)
          throws DatabaseException {
    // Create one set of worker threads for each base DN.
    int importThreadCount = config.getImportThreadCount();
    for (ImportContext ic : importMap.values())
    {
      for (int i = 0; i < importThreadCount; i++)
      {
        ImportThreadProto t = new ImportThreadProto(ic,  budgetLimit, i, this);
        t.setUncaughtExceptionHandler(this);
        threads.add(t);

        t.start();
      }
    }

    // Start a timer for the progress report.
    timer = new Timer();
    progressTask = new ImportJobProto.ProgressTask();
    timer.scheduleAtFixedRate(progressTask, progressInterval,
                              progressInterval);

  }


  /**
   * Import a ldif using the specified root container.
   *
   * @param rootContainer  The root container.
   * @return A LDIF result.
   * @throws DatabaseException  If a DB error occurs.
   * @throws IOException If a IO error occurs.
   * @throws JebException If a JEB error occurs.
   * @throws DirectoryException If a directory error occurs.
   * @throws ConfigException If a configuration has an error.
   */
  public LDIFImportResult importLDIF(RootContainer rootContainer)
      throws DatabaseException, IOException, JebException, DirectoryException,
            ConfigException {

    // Create an LDIF reader. Throws an exception if the file does not exist.
    reader = new LDIFReader(ldifImportConfig);
    this.rootContainer = rootContainer;
    this.config = rootContainer.getConfiguration();

    Message message;
    long startTime;

    try
    {
      int importThreadCount = config.getImportThreadCount();
      message = INFO_JEB_IMPORT_STARTING.get(DirectoryServer.getVersionString(),
                                                     BUILD_ID, REVISION_NUMBER);
      logError(message);
      message = INFO_JEB_IMPORT_THREAD_COUNT.get(importThreadCount);
      logError(message);
      RuntimeInformation.logInfo();
      for (EntryContainer entryContainer : rootContainer.getEntryContainers()) {
        ImportContext importContext =  getImportContext(entryContainer);
        if(importContext != null) {
          importMap.put(entryContainer.getBaseDN(), importContext);
        }
      }
      // Make a note of the time we started.
      startTime = System.currentTimeMillis();
      //Figure out the import buffer sizes to give to each thread.
      long importSize=getImportBufferSize();
      startWorkerThreads(importSize);
      try
      {
        importedCount = 0;
        processLDIF();
      }
      finally
      {
         stopWorkerThreads();
      }
    }
    finally
    {
      reader.close();
    }

    long finishTime = System.currentTimeMillis();
    long importTime = (finishTime - startTime);

    float rate = 0;
    if (importTime > 0)
    {
      rate = 1000f*importedCount / importTime;
    }

    message = INFO_JEB_IMPORT_FINAL_STATUS.
        get(reader.getEntriesRead(), importedCount - 0,
            reader.getEntriesIgnored(), reader.getEntriesRejected(),
            0, importTime/1000, rate);
    logError(message);

    message = INFO_JEB_IMPORT_ENTRY_LIMIT_EXCEEDED_COUNT.get(
        getEntryLimitExceededCount());
    logError(message);

    return new LDIFImportResult(reader.getEntriesRead(),
                                reader.getEntriesRejected(),
                                reader.getEntriesIgnored());
  }



   private void processLDIF()
      throws JebException, DatabaseException, IOException {
       Message message = INFO_JEB_IMPORT_LDIF_START.get();
    logError(message);

    do
    {
      if (ldifImportConfig.isCancelled())
      {
        break;
      }

      if(threads.size() <= 0)
      {
        message = ERR_JEB_IMPORT_NO_WORKER_THREADS.get();
        throw new JebException(message);
      }
      try
      {
        // Read the next entry.
        Entry entry = reader.readEntry();

        // Check for end of file.
        if (entry == null)
        {
          message = INFO_JEB_IMPORT_LDIF_END.get();
          logError(message);

          break;
        }

        // Route it according to base DN.
        ImportContext importContext = getImportConfig(entry.getDN());

        processEntry(importContext, entry);

      }
      catch (LDIFException e)
      {
        if (debugEnabled())
        {
          TRACER.debugCaught(DebugLogLevel.ERROR, e);
        }
      }
      catch (DirectoryException e)
      {
        if (debugEnabled())
        {
          TRACER.debugCaught(DebugLogLevel.ERROR, e);
        }
      }
    } while (true);
   }

  /**
   * Process an entry using the specified import context. Needs support for
   * VLVIndexes and DN2URI.
   *
   * @param importContext The import context.
   * @param entry The entry to process.
   * @throws JebException If a JEB error occurs.
   * @throws DatabaseException If a database error occurs.
   * @throws DirectoryException If a directory error occurs.
   */
  public void processEntry(ImportContext importContext, Entry entry)
          throws JebException, DatabaseException, DirectoryException {
    DN entryDN = entry.getDN();
    DN2ID dn2id = importContext.getEntryContainer().getDN2ID();

    EntryID entryID = dn2id.get(null, entryDN);
    if (entryID != null) {
      Message msg = WARN_JEB_IMPORT_ENTRY_EXISTS.get();
      importContext.getLDIFReader().rejectLastEntry(msg);
    }  else {
      EntryID parentID = null;
      DN parentDN = importContext.getEntryContainer().
              getParentWithinBase(entryDN);
      if (parentDN != null) {
        parentID = getParentID(parentDN, dn2id, null);
        if (parentID == null)
        {
          // Reject the entry.
          Message msg =
                  ERR_JEB_IMPORT_PARENT_NOT_FOUND.get(parentDN.toString());
          importContext.getLDIFReader().rejectLastEntry(msg);
          return;
        }
      }

      // Assign a new entry identifier and write the new DN.
      entryID = rootContainer.getNextEntryID();
      dn2id.insert(null, entryDN, entryID);

      ArrayList<EntryID> IDs;
      if (parentDN != null && importContext.getParentDN() != null &&
              parentDN.equals(importContext.getParentDN())) {
        // Reuse the previous values.
        IDs = new ArrayList<EntryID>(importContext.getIDs());
        IDs.set(0, entryID);
      }
      else {
        IDs = new ArrayList<EntryID>(entryDN.getNumComponents());
        IDs.add(entryID);
        if (parentID != null)
        {
          IDs.add(parentID);
          EntryContainer ec = importContext.getEntryContainer();
          for (DN dn = ec.getParentWithinBase(parentDN); dn != null;
               dn = ec.getParentWithinBase(dn))
          {
            // Read the ID from dn2id.
            EntryID nodeID = dn2id.get(null, dn);
            IDs.add(nodeID);
          }
        }
      }
      importContext.setParentDN(parentDN);
      importContext.setIDs(IDs);
      if(!addID2EntryQueue(importContext, entryID, entry))
        return;
      if(!addID2SubtreeChildrenQueue(importContext, IDs))
        return;
      addIndexesQueue(importContext, IDs, entry);
    }
  }

  /**
   * Add work item to specified import context's queue.
   * @param importContext The import context.
   * @param item The work item to add.
   * @return <CODE>True</CODE> if the the work  item was added to the queue.
   */
  private boolean
  addQueue(ImportContext importContext, ImportWorkItemProto item) {
    try {
      while(!importContext.getQueueNewArch().offer(item, 1000,
                                            TimeUnit.MILLISECONDS)) {
        if(threads.size() <= 0) {
          // All worker threads died. We must stop now.
          return false;
        }
      }
    } catch (InterruptedException e) {
      if (debugEnabled()) {
        TRACER.debugCaught(DebugLogLevel.ERROR, e);
      }
    }
    return true;
  }

  /**
   * Get the Entry ID of the parent entry.
   * @param parentDN  The parent DN.
   * @param dn2id The DN2ID DB.
   * @param txn A database transaction,
   * @return The entry ID of the parent entry.
   * @throws DatabaseException If a DB error occurs.
   */
   private EntryID getParentID(DN parentDN, DN2ID dn2id, Transaction txn)
          throws DatabaseException {
    EntryID parentID = parentIDMap.get(parentDN);
    if (parentID != null)
    {
      return parentID;
    }

    parentID = dn2id.get(txn, parentDN);
    if (parentID != null)
    {
      if (parentIDMap.size() >= PARENT_ID_MAP_SIZE)
      {
        Iterator<DN> iterator = parentIDMap.keySet().iterator();
        iterator.next();
        iterator.remove();
      }

      parentIDMap.put(parentDN, parentID);
    }
    return parentID;
  }

  /**
   * Stop the worker threads.
   *
   * @throws DatabaseException If a DB error occurs.
   */
  private void stopWorkerThreads() throws DatabaseException {
    if(threads.size() > 0) {
      // Wait for the queues to be drained.
      for (ImportContext ic : importMap.values()) {
        while (ic.getQueueNewArch().size() > 0) {
          try {
            Thread.sleep(100);
          } catch (Exception e) {
            // No action needed.
          }
        }
      }
    }

    // Order the threads to stop.
    for (ImportThreadProto t : threads) {
      t.stopProcessing();
    }

    // Wait for each thread to stop.
    for (ImportThreadProto t : threads) {
      try {
        t.join();
        importedCount += t.getImportedCount();
      } catch (InterruptedException ie) {
        // No action needed?
      }
    }
    for(ImportContext ic : importMap.values()) {
      ic.setIndexesTrusted();
    }
    timer.cancel();
  }

  /**
   * Uncaught exception handler.
   *
   * @param t The thread working when the exception was thrown.
   * @param e The exception.
   */
  public void uncaughtException(Thread t, Throwable e) {
     threads.remove(t);
     Message msg = ERR_JEB_IMPORT_THREAD_EXCEPTION.get(
         t.getName(), StaticUtils.stackTraceToSingleLineString(e.getCause()));
     logError(msg);
   }

  /**
   * Get the entry limit exceeded counts from the indexes.
   *
   * @return Count of the index with entry limit exceeded values.
   */
  private int getEntryLimitExceededCount() {
    int count = 0;
    for (ImportContext ic : importMap.values())
    {
      count += ic.getEntryContainer().getEntryLimitExceededCount();
    }
    return count;
  }

  /**
   * Return an import context related to the specified DN.
   * @param dn The dn.
   * @return  An import context.
   * @throws DirectoryException If an directory error occurs.
   */
  private ImportContext getImportConfig(DN dn) throws DirectoryException {
    ImportContext importContext = null;
    DN nodeDN = dn;

    while (importContext == null && nodeDN != null) {
      importContext = importMap.get(nodeDN);
      if (importContext == null)
      {
        nodeDN = nodeDN.getParentDNInSuffix();
      }
    }

    if (nodeDN == null) {
      // The entry should not have been given to this backend.
      Message message =
              JebMessages.ERR_JEB_INCORRECT_ROUTING.get(String.valueOf(dn));
      throw new DirectoryException(ResultCode.NO_SUCH_OBJECT, message);
    }

    return importContext;
  }

  /**
   * Creates an import context for the specified entry container.
   *
   * @param entryContainer The entry container.
   * @return Import context to use during import.
   * @throws DatabaseException If a database error occurs.
   * @throws JebException If a JEB error occurs.
   * @throws ConfigException If a configuration contains error.
   */
   private ImportContext getImportContext(EntryContainer entryContainer)
      throws DatabaseException, JebException, ConfigException {
    DN baseDN = entryContainer.getBaseDN();
    EntryContainer srcEntryContainer = null;
    List<DN> includeBranches = new ArrayList<DN>();
    List<DN> excludeBranches = new ArrayList<DN>();

    if(!ldifImportConfig.appendToExistingData() &&
        !ldifImportConfig.clearBackend())
    {
      for(DN dn : ldifImportConfig.getExcludeBranches())
      {
        if(baseDN.equals(dn))
        {
          // This entire base DN was explicitly excluded. Skip.
          return null;
        }
        if(baseDN.isAncestorOf(dn))
        {
          excludeBranches.add(dn);
        }
      }

      if(!ldifImportConfig.getIncludeBranches().isEmpty())
      {
        for(DN dn : ldifImportConfig.getIncludeBranches())
        {
          if(baseDN.isAncestorOf(dn))
          {
            includeBranches.add(dn);
          }
        }

        if(includeBranches.isEmpty())
        {
          // There are no branches in the explicitly defined include list under
          // this base DN. Skip this base DN alltogether.

          return null;
        }

        // Remove any overlapping include branches.
        Iterator<DN> includeBranchIterator = includeBranches.iterator();
        while(includeBranchIterator.hasNext())
        {
          DN includeDN = includeBranchIterator.next();
          boolean keep = true;
          for(DN dn : includeBranches)
          {
            if(!dn.equals(includeDN) && dn.isAncestorOf(includeDN))
            {
              keep = false;
              break;
            }
          }
          if(!keep)
          {
            includeBranchIterator.remove();
          }
        }

        // Remvoe any exclude branches that are not are not under a include
        // branch since they will be migrated as part of the existing entries
        // outside of the include branches anyways.
        Iterator<DN> excludeBranchIterator = excludeBranches.iterator();
        while(excludeBranchIterator.hasNext())
        {
          DN excludeDN = excludeBranchIterator.next();
          boolean keep = false;
          for(DN includeDN : includeBranches)
          {
            if(includeDN.isAncestorOf(excludeDN))
            {
              keep = true;
              break;
            }
          }
          if(!keep)
          {
            excludeBranchIterator.remove();
          }
        }

        if(includeBranches.size() == 1 && excludeBranches.size() == 0 &&
            includeBranches.get(0).equals(baseDN))
        {
          // This entire base DN is explicitly included in the import with
          // no exclude branches that we need to migrate. Just clear the entry
          // container.
          entryContainer.exclusiveLock.lock();
          entryContainer.clear();
          entryContainer.exclusiveLock.unlock();
        }
        else
        {
          // Create a temp entry container
          srcEntryContainer = entryContainer;
          entryContainer =
              rootContainer.openEntryContainer(baseDN,
                                               baseDN.toNormalizedString() +
                                                   "_importTmp");
        }
      }
    }

    // Create an import context.
    ImportContext importContext = new ImportContext();
    importContext.setConfig(config);
    importContext.setLDIFImportConfig(this.ldifImportConfig);
    importContext.setLDIFReader(reader);

    importContext.setBaseDN(baseDN);
    importContext.setEntryContainer(entryContainer);
    importContext.initAttrIndexes();
    importContext.setSrcEntryContainer(srcEntryContainer);

    //Create queue.
    LinkedBlockingQueue<ImportWorkItemProto> queue =
        new LinkedBlockingQueue<ImportWorkItemProto>
                     (config.getImportQueueSize());
    importContext.setQueueNewArch(queue);

    // Set the include and exclude branches
    importContext.setIncludeBranches(includeBranches);
    importContext.setExcludeBranches(excludeBranches);

    return importContext;
  }


  /**
   * Attempts to figure out how big the buffer size (per thread) should be.
   *
   *
   * @return the buffer size each thread should use.
   * @throws DatabaseException  if there was a DB error.
   */
  private long getImportBufferSize() throws DatabaseException {
    int tCount=config.getImportThreadCount();
    EnvironmentStats envStats =
            rootContainer.getEnvironmentStats(new StatsConfig());
    long logSize=envStats.getBufferBytes();
    EnvironmentMutableConfig mutableConfig =
            rootContainer.getEnvironmentConfig();
    long dbCacheSize=mutableConfig.getCacheSize();
    Runtime runtime = Runtime.getRuntime();
    long freeMemory = runtime.freeMemory();
    long maxMemory = runtime.maxMemory();
    long totMemory = runtime.totalMemory();
    long totFreeMemory = (freeMemory + (maxMemory - totMemory));
    long slop = (totFreeMemory * 20) / 100;
    long importBufferSize = config.getImportBufferSize();
    long retSize = totFreeMemory - (slop + dbCacheSize + logSize);
    if(retSize < importBufferSize) {
      if(retSize < ProgressTask.bytesPerMegabyte) {
        retSize=ProgressTask.bytesPerMegabyte;
      }
      Message message = INFO_JEB_IMPORT_BUFFER_SIZE_DEFAULT.get(
              importBufferSize);
      logError(message);
    } else {
      retSize = importBufferSize;
    }
    retSize=retSize/tCount;
    Message message=INFO_JEB_IMPORT_MEMORY_BUFFER_STATS.get(retSize, logSize,
            dbCacheSize/ProgressTask.bytesPerMegabyte,
            freeMemory/ProgressTask.bytesPerMegabyte,
            totMemory/ProgressTask.bytesPerMegabyte,
            totFreeMemory/ProgressTask.bytesPerMegabyte,
            slop/ProgressTask.bytesPerMegabyte,
            importBufferSize);
    logError(message);
    return retSize;
  }

  /**
   * Adds a ID2ENTRY work item to the queue of the specified import context.
   *
   * @param importContext The import context.
   * @param entryID The entryID to use as the DB key.
   * @param e The entry to add to the ID2ENTRY DB.
   * @return <CODE>True</CODE> if the ID2ENTRY was added to the queue.
   * @throws DirectoryException If a directory error occurs.
   */
  private boolean addID2EntryQueue(ImportContext importContext, EntryID entryID,
                                   Entry e)
          throws DirectoryException {
    ID2Entry id2entry = importContext.getEntryContainer().getID2Entry();
    ImportWorkItemProto workItem = ImportWorkItemProto.decode(id2entry,
            entryID.getDatabaseEntry(), id2entry.entryData(e), this);
    return addQueue(importContext, workItem);
  }

  /**
   * Add ID2CHILDREN/ID2SUBTREE work item to the queue of the specified import
   * context.
   * @param importContext The import context.
   * @param IDs List of IDs to add to the indexes.
   * @return <CODE>True</CODE> if the work item was added to the queue.
   */
  private boolean addID2SubtreeChildrenQueue(ImportContext importContext,
                                             ArrayList<EntryID> IDs ) {

    Index id2children = importContext.getEntryContainer().getID2Children();
    Index id2subtree = importContext.getEntryContainer().getID2Subtree();
    ImportWorkItemProto childItem =
                               ImportWorkItemProto.decode(id2children, IDs,
                                                          this);
    if(!addQueue(importContext, childItem)) {
      return false;
    }
    ImportWorkItemProto subtreeItem =
                                  ImportWorkItemProto.decode(id2subtree, IDs,
                                                             this);
    if(!addQueue(importContext, subtreeItem)) {
      return false;
    }
    return true;
  }

  /**
   * Add a work item to the queue for each index in the index map if the
   * index exists in the container and the specifed entry contains the
   * attribute.
   *
   * @param importContext   The import context.
   * @param IDs List of IDs to add to the indexes.
   * @param entry The entry.
   * @return <CODE>True</CODE> if the work item was added to the queue.
   */
  private boolean addIndexesQueue(ImportContext importContext,
                                  ArrayList<EntryID> IDs, Entry entry) {
    LinkedHashMap<AttributeType, ImportIndexContainer> indexMap =
            importContext.getAttrIndexMap();

    for(Map.Entry<AttributeType, ImportIndexContainer> hashEntry :
            indexMap.entrySet()) {
      AttributeType attrType = hashEntry.getKey();
      List<Attribute> aList=entry.getAttribute(attrType);
      if(entry.hasUserAttribute(attrType) ||
              entry.hasOperationalAttribute(attrType) ||
              attrType.isObjectClassType()) {
        ImportIndexContainer container = hashEntry.getValue();
        if(container.getAttributeIndex().substringIndex != null) {
          ImportWorkItemProto item = ImportWorkItemProto.decode(
                  container.getAttributeIndex().substringIndex,
                  aList, IDs, this);
          if(!addQueue(importContext, item)) {
            return false;
          }
        }
        if(container.getAttributeIndex().equalityIndex != null) {
          ImportWorkItemProto eqItem = ImportWorkItemProto.decode(
                  container.getAttributeIndex().equalityIndex,
                  aList, IDs, this);
          if(!addQueue(importContext, eqItem)) {
            return false;
          }
        }
        if(container.getAttributeIndex().presenceIndex != null) {
          ImportWorkItemProto item = ImportWorkItemProto.decode(
                  container.getAttributeIndex().presenceIndex,
                  aList, IDs, this);
          if(!addQueue(importContext, item)) {
            return false;
          }
        }
        if(container.getAttributeIndex().orderingIndex != null) {
          ImportWorkItemProto item = ImportWorkItemProto.decode(
                  container.getAttributeIndex().orderingIndex,
                  aList, IDs, this);
          if(!addQueue(importContext, item)) {
            return false;
          }
        }
        if(container.getAttributeIndex().approximateIndex != null) {
          ImportWorkItemProto item = ImportWorkItemProto.decode(
                  container.getAttributeIndex().approximateIndex,
                  aList, IDs, this);
          if(!addQueue(importContext, item)) {
            return false;
          }
        }
      }
    }
    return true;
  }


  public ByteArray checkKeyMap(ByteArray byteArray) {
    ByteArray ret;
    if(!keyMap.containsKey(byteArray)) {
      int len = byteArray.array().length;
      byte[] bytes = new byte[len];
      System.arraycopy(byteArray.array(), 0, bytes, 0, len);
      ByteArray newBa = new ByteArray(new DatabaseEntry(bytes));
      ret = newBa;
    } else {
      keyHit++;
      ret = keyMap.get(byteArray);
     // System.out.println(keyEff + " " + keyMap.size());
    }
    return ret;
  }


  public void insertIfNeeded(ByteArray byteArray,
                             ImportMemoryBudgetProto memBudget) {
    ByteArray ba = keyMap.putIfAbsent(byteArray, byteArray);
    if(ba == null) {
      memBudget.addMemoryUsage(byteArray);
    }
  }

  /**
   * This class reports progress of the import job at fixed intervals.
   */
  class ProgressTask extends TimerTask
  {
    /**
     * The number of entries that had been read at the time of the
     * previous progress report.
     */
    private long previousCount = 0;

    /**
     * The time in milliseconds of the previous progress report.
     */
    private long previousTime;

    /**
     * The environment statistics at the time of the previous report.
     */
    private EnvironmentStats prevEnvStats;

    /**
     * The number of bytes in a megabyte.
     * Note that 1024*1024 bytes may eventually become known as a mebibyte(MiB).
     */
    public static final int bytesPerMegabyte = 1024*1024;

    private boolean ldifRead=false;

    /**
     * Create a new import progress task.
     * @throws DatabaseException If an error occurs in the JE database.
     */
    public ProgressTask() throws DatabaseException
    {
      previousTime = System.currentTimeMillis();
      prevEnvStats = rootContainer.getEnvironmentStats(new StatsConfig());
    }

    /**
     * Return if reading the LDIF file.
     */
    public void ldifRead() {
      ldifRead=true;
    }

    /**
     * The action to be performed by this timer task.
     */
    public void run()
    {
      long latestCount = reader.getEntriesRead() + 0;
      long deltaCount = (latestCount - previousCount);
      long latestTime = System.currentTimeMillis();
      long deltaTime = latestTime - previousTime;

      Message message;

      if (deltaTime == 0)
      {
        return;
      }

      if(!ldifRead) {
        long numRead     = reader.getEntriesRead();
        long numIgnored  = reader.getEntriesIgnored();
        long numRejected = reader.getEntriesRejected();
         float rate = 1000f*deltaCount / deltaTime;

         message = INFO_JEB_IMPORT_PROGRESS_REPORT.get(
            numRead, numIgnored, numRejected, 0, rate);
        logError(message);
      }

      try
      {
        Runtime runtime = Runtime.getRuntime();
        long freeMemory = runtime.freeMemory() / bytesPerMegabyte;

        EnvironmentStats envStats =
            rootContainer.getEnvironmentStats(new StatsConfig());
        long nCacheMiss =
            envStats.getNCacheMiss() - prevEnvStats.getNCacheMiss();

        float cacheMissRate = 0;
        if (deltaCount > 0)
        {
          cacheMissRate = nCacheMiss/(float)deltaCount;
        }

        message = INFO_JEB_IMPORT_CACHE_AND_MEMORY_REPORT.get(
            freeMemory, cacheMissRate);
        logError(message);
        long evictPasses = envStats.getNEvictPasses();
        long evictNodes = envStats.getNNodesExplicitlyEvicted();
        long evictBinsStrip = envStats.getNBINsStripped();
        if(evictPasses > 0) {
             message = INFO_JEB_IMPORT_EVICTION.get(evictPasses,
                                                evictNodes, evictBinsStrip);
            logError(message);
        }
        prevEnvStats = envStats;


      }
      catch (DatabaseException e)
      {
        // Unlikely to happen and not critical.
      }


      previousCount = latestCount;
      previousTime = latestTime;
    }
  }


}

