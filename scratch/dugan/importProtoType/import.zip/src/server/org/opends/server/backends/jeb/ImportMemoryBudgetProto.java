/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE
 * or https://OpenDS.dev.java.net/OpenDS.LICENSE.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at
 * trunk/opends/resource/legal-notices/OpenDS.LICENSE.  If applicable,
 * add the following below this CDDL HEADER, with the fields enclosed
 * by brackets "[]" replaced with your own identifying information:
 *      Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 *
 *
 *      Portions Copyright 2008 Sun Microsystems, Inc.
 */

package org.opends.server.backends.jeb;

import com.sleepycat.je.dbi.MemoryBudget;
import org.opends.server.util.RuntimeInformation;


/**
 * The ImportMemoryBudget class is part of the import prototype class.
 * It keeps track of the memory used by the import buffers. It mostly uses
 * the memory budget class that the Java DB cache uses. The values not
 * defined in the Java Edition class were gathered from jhat historgram dumps.
 * It's pretty close from what I can tell.
 *
 * Note the 64 bit values have not been collected yet.
 */
public class ImportMemoryBudgetProto {

  private long memoryUsage;

  private long budgetLimit;

  private final static int LONGS_OVERHEAD;
  private final static int LONGS_OVERHEAD_32=16;

  private final static int HASH_MAP_OVERHEAD;
  private final static int HASH_MAP_OVERHEAD_32=32;

  private final static int HASH_MAP_ENTRY_OVERHEAD;
  private final static int HASH_MAP_ENTRY_OVERHEAD_32=25;


  static {
    if(RuntimeInformation.is64Bit()) {
      //Use 32 bit values for now.
      HASH_MAP_OVERHEAD=HASH_MAP_OVERHEAD_32;
      HASH_MAP_ENTRY_OVERHEAD=HASH_MAP_ENTRY_OVERHEAD_32;
      LONGS_OVERHEAD=LONGS_OVERHEAD_32;
    } else {
      HASH_MAP_OVERHEAD=HASH_MAP_OVERHEAD_32;
      HASH_MAP_ENTRY_OVERHEAD=HASH_MAP_ENTRY_OVERHEAD_32;
      LONGS_OVERHEAD=LONGS_OVERHEAD_32;
    }
  }

  /**
   * Create a memory budget class with the specified budget limit.
   *
   * @param budgetLimit The budge limit.
   */
  public ImportMemoryBudgetProto(long budgetLimit) {
    this.budgetLimit=budgetLimit;
    memoryUsage=0;
  }

  /**
   * Add usage of long.
   */
  public void addMemoryUsageLongs() {
    memoryUsage += LONGS_OVERHEAD;
  }

  /**
   * Remove usage of a long.
   */
  public void removeMemoryUsageLongs() {
    memoryUsage -= LONGS_OVERHEAD;
  }

  /**
   * Add usage of the specified byte array and count representing an array
   * of longs. The LONGS_OVERHEAD and HASH_MAP_ENTRY  are added also. This is
   * when a new ID is added to a key hash map.
   *
   * @param b The byte array representing the key.
   * @param count The count of the long array.
   */
  public void addMemoryUsage(byte[] b, int count) {
    memoryUsage += MemoryBudget.byteArraySize(b.length) +
                  MemoryBudget.byteArraySize(8 * count) + LONGS_OVERHEAD +
                  HASH_MAP_ENTRY_OVERHEAD;
  }

   /**
   * Remove usage of the specified byte array and count representing an array
   * of longs. The LONGS_OVERHEAD and HASH_MAP_ENTRY  are added also. This is
   * when a new ID is added to a key hash map.
   *
   * @param b The byte array representing the key.
   * @param count The count of the long array.
   */

   public void removeMemoryUsage(byte[] b, int count) {
    memoryUsage -= MemoryBudget.byteArraySize(b.length) +
                  MemoryBudget.byteArraySize(8 * count) + LONGS_OVERHEAD +
                  HASH_MAP_ENTRY_OVERHEAD;
  }

  /**
   * Add memory usage of an set of longs. Used when an array has been
   * resized.
   *
   * @param count  The size of the array.
   */
  public void addMemoryUsageLong(int count) {
    memoryUsage += (count * MemoryBudget.LONG_OVERHEAD);
  }

  /**
   * Add memory usage of the specified byte array.
   *
   * @param b The byte array.
   */
  public void addMemoryUsage(byte[] b) {
    memoryUsage += MemoryBudget.byteArraySize(b.length);
  }

  /**
   * Remove memory usage of the specified byte array.
   *
   * @param b The byte array.
   */

  public void removeMemoryUsage(byte[] b) {
    memoryUsage -= MemoryBudget.byteArraySize(b.length);
  }

  /**
   * Add memory usage of the specified long array size.
   *
   * @param length The long array size.
   */
  public void addMemoryUsage(int length) {
    memoryUsage += MemoryBudget.byteArraySize(8 * length);
  }

  /**
   * Remove memory usage of the specified long array size.
   *
   * @param length The long array size.
   */

  public void removeMemoryUsage(int length) {
    memoryUsage -= MemoryBudget.byteArraySize(8 * length);
  }


  /**
   * Add memory usage of a hash map entry.
   */
  public void addMemoryUsageHashMapEntry() {
    memoryUsage += HASH_MAP_ENTRY_OVERHEAD;
  }

  /**
   * Remove usage of a hash map entry.
   */
  public void addMemoryUsageHashMap() {
    memoryUsage += HASH_MAP_OVERHEAD;
  }

  /**
   * Return true if the memory usage plus specified extra space is above the
   * memory budget limit.
   *
   * @param extraSpace The extra space.
   * @return <CODE>True</CODE> if the memory usage plus extra is above the
   * memory budget.
   */
  public boolean overBudgetLimit(long extraSpace) {
    if(memoryUsage == 0)
      return false;
    return (memoryUsage + extraSpace) > budgetLimit;
  }

  public static long getMemorySize(int length) {
    return  MemoryBudget.byteArraySize(length);
  }

}
